import { combineReducers } from 'redux'
import addCandidateReducer from './addCandidateReducer'
import addJobReducer from './addJobReducer'
import candidateDetailsReducer from './candidateDetailsReducer'
import candidatesReducer from './candidatesReducer'
import dashboardReducer from './dashboardReducer'
import editCandidateReducer from './editCandidateReducer'
import editJobReducer from './editJobReducer'
import jobDetailsReducer from './jobDetailsReducer'
import jobsReducer from './jobsReducer'
import masterdataReducer from './masterdataReducer'
import userReducer from './userReducer'

export default () => combineReducers({
  // login: loginReducer,
  user: userReducer,
  masterData: masterdataReducer,
  dashboard: dashboardReducer,
  jobs: jobsReducer,
  addJob: addJobReducer,
  jobDetails: jobDetailsReducer,
  editJob: editJobReducer,
  candidates: candidatesReducer,
  addCandidate: addCandidateReducer,
  candidateDetails: candidateDetailsReducer,
  editCandidate: editCandidateReducer
})
