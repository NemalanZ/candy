import { createSelector } from 'reselect'
import { prop } from 'ramda'
import { CANDIDATE_DETAILS_ACTION as ACTIONS } from '../actions'
import getCandidateDetailsApi from '../../api/getCandidateDetails'
import getCandidateRoundsApi from '../../api/getCandidateRounds'
import getCandidateStatusApi from '../../api/getCandidateStatus'

const initialState = {
  error: null,
  loading: false,
  candidateDetails: {},
  jobId: '',
  jobTitle: '',
  candidateId: '',
  firstName: '',
  lastName: '',
  gender: '',
  emailId: '',
  phone: '',
  experience: '',
  mainSkill: '',
  secondarySkill: '',
  address: '',
  city: '',
  pinCode: '',
  state: '',
  country: '',
  round: '',
  resume: '',
  appliedJobs: [],
  candidateRounds: [],
  candidateStatus: [],
}

const getSlice = prop('candidateDetails')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getJobId = createSelector(getSlice, prop('jobId'))
export const getJobTitle = createSelector(getSlice, prop('jobTitle'))
export const getCandidateDetails = createSelector(getSlice, prop('candidateDetails'))
export const getCandidateId = createSelector(getSlice, prop('candidateId'))
export const getFirstName = createSelector(getSlice, prop('firstName'))
export const getLastName = createSelector(getSlice, prop('lastName'))
export const getGender = createSelector(getSlice, prop('gender'))
export const getEmailId = createSelector(getSlice, prop('emailId'))
export const getPhone = createSelector(getSlice, prop('phone'))
export const getExperience = createSelector(getSlice, prop('experience'))
export const getMainSkill = createSelector(getSlice, prop('mainSkill'))
export const getSecondarySkill = createSelector(getSlice, prop('secondarySkill'))
export const getAddress = createSelector(getSlice, prop('address'))
export const getCity = createSelector(getSlice, prop('city'))
export const getPinCode = createSelector(getSlice, prop('pinCode'))
export const getStateValue = createSelector(getSlice, prop('state'))
export const getCountry = createSelector(getSlice, prop('country'))
export const getResume = createSelector(getSlice, prop('resume'))
export const getRound = createSelector(getSlice, prop('round'))
export const getAppliedJobs = createSelector(getSlice, prop('appliedJobs'))
export const getCandidateRounds = createSelector(getSlice, prop('candidateRounds'))
export const getCandidateStatus = createSelector(getSlice, prop('candidateStatus'))

export const fetchCandidateDetails = (id) => async (dispatch, getState) => {
  dispatch({
    type: ACTIONS.GET_CANDIDATE_DETAILS_REQUEST
  })
  try {
    const candidateDetailsData = await getCandidateDetailsApi(id)
    dispatch({
      type: ACTIONS.GET_CANDIDATE_DETAILS_SUCCESS,
      data: candidateDetailsData
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.GET_CANDIDATE_DETAILS_FAILURE,
      error
    })
  };
}

export const fetchMasterData = (id) => async (dispatch) => {
  dispatch({
    type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_REQUEST
  })
  try {
    const candidateRoundsData = await getCandidateRoundsApi()
    const candidateStatusData = await getCandidateStatusApi()

    const data = {
      candidateRoundsData,
      candidateStatusData,
    }
    // console.log('masterData', data)
    dispatch({
      type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_SUCCESS,
      masterData: data
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_FAILURE,
      error
    })
  }
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_SUCCESS:
      return {
        ...state,
        candidateRounds: action.masterData.candidateRoundsData,
        candidateStatus: action.masterData.candidateStatusData,
        loading: false,
        error: false
      }
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.GET_CANDIDATE_DETAILS_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.GET_CANDIDATE_DETAILS_SUCCESS: {
      return {
        ...state,
        candidateDetails: action.data,
        jobId: prop('job_id', action.data),
        jobTitle: prop('job_title', action.data),
        candidateId: prop('candidate_id', action.data),
        firstName: prop('first_name', action.data),
        lastName: prop('last_name', action.data),
        gender: prop('gender', action.data),
        emailId: prop('email', action.data),
        phone: prop('contact_no', action.data),
        experience: prop('experience', action.data),
        mainSkill: prop('main_skill', action.data),
        secondarySkill: prop('secondary_skill', action.data),
        address: prop('address', action.data),
        city: prop('city_name', action.data),
        pinCode: prop('pin_code', action.data),
        state: prop('state_name', action.data),
        country: prop('country_name', action.data),
        // candidateRounds: prop('selection_status_name', action.data),
        // candidateStatus: prop('profile_status_name', action.data),
        resume: prop('resume', action.data),
        appliedJobs: prop('Applied_Jobs', action.data),
        round: prop('Applied_Jobs[0].job_title', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.GET_CANDIDATE_DETAILS_FAILURE: {
      return {
        ...state,
        error: action.error,
        location: false
      }
    }
    default:
      return initialState
  }
}
