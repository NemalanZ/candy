import React, { lazy } from 'react'
import MinimalLayout from '../app/Layout/MinimalLayout'
import SuspenseLoader from '../components/SuspenseLoader'

const RegisterPage = SuspenseLoader(lazy(() => import('../app/Main/Authentication/Register')))
const LoginComponent = SuspenseLoader(lazy(() => import('../app/Main/Authentication/Login')))

const LoginRoutes = {
  path: '/auth',
  element: <MinimalLayout />,
  children: [
    {
      path: 'login',
      element: <LoginComponent />
    },
    {
      path: 'register',
      element: <RegisterPage />
    }
  ]
}

export default LoginRoutes
