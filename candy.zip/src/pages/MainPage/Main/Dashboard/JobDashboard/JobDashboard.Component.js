import { Table } from 'antd'
import {
  CategoryScale, Chart as ChartJS, LinearScale, LineElement, PointElement, Title,
  Tooltip
} from 'chart.js'
import { isEmpty } from 'ramda'
import React, { useEffect, useState } from 'react'
import { Line } from 'react-chartjs-2'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link } from 'react-router-dom'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip

)

const JobsDashboard = ({
  fetchDashboardData,
  allCandidates,
  allJobs,
  clients,
  sliceJobs,
  sliceCandidates
}) => {
  const [page, setPage] = useState(1)

  const totalJobs = allJobs.length
  const totalCandidates = allCandidates.length
  const totalClients = clients.length

  const latestJobs = sliceJobs
  const latestCandidates = sliceCandidates

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const jobsData = !isEmpty(latestJobs) ? latestJobs.map((details, index) => ({
    ...details,
    key: index,
    id: details.job_id,
    role: details.job_title,
    client: details.company_name,
    experience: `${details.experience}`,
    vacancy: details.vacancy_count,
    location: details.city_name,
    // location: `${details.city}, ${details.state}`, .split("").reverse().join("")
    dateOfReq: details.date_of_requisition.slice(0, 10),
    jobType: details.job_type_name
  })) : []

  const columnsLastestJobs = [
    {
      dataIndex: 'role'
    },
    {
      dataIndex: 'dateOfReq',
      align: 'right'
    }
  ]

  const columnsJobs = [
    {
      title: 'Id',
      key: 'serial',
      dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Job Title',
      dataIndex: 'role',
      editTable: true,
      render: (_, record) => (
        <Link to={`/jobs/jobDetails/${record.id}`}>{record.role}</Link>
      ),
      sorter: (a, b) => a.role.localeCompare(b.role)
    },

    {
      title: 'Client',
      dataIndex: 'client',
      sorter: (a, b) => a.client.localeCompare(b.client)
    },
    {
      title: 'Experience',
      dataIndex: 'experience'
      // sorter: (a, b) => a.experience.localeCompare(b.experience)
    },
    {
      title: 'Vacancy',
      dataIndex: 'vacancy',
      sorter: (a, b) => a.vacancy - b.vacancy
    },
    {
      title: 'location',
      dataIndex: 'location'
      // sorter: (a, b) => a.location - b.location,
    },
    {
      title: 'Job Type',
      dataIndex: 'jobType',
      sorter: (a, b) => a.jobType.localeCompare(b.jobType)
    },
    {
      title: 'Start Date',
      dataIndex: 'dateOfReq'
      // sorter: (a, b) => new Date(a.dateOfReq) - new Date(b.dateOfReq)
    }
  ]

  const candidatesData = !isEmpty(latestCandidates) ? latestCandidates.map((details, index) => ({
    ...details,
    key: index,
    id: details.candidate_id,
    name: `${details.first_name} ${details.last_name}`,
    // role: details.gridData.role,
    experience: `${details.experience}`,
    location: `${details.city_name}, ${details.state_name}`,
    emailId: details.email,
    phone: details.contact_no
  })) : []

  const columnsCandidates = [
    {
      title: 'Id',
      key: 'serial',
      dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Name',
      dataIndex: 'name',
      editTable: true,
      render: (_, record) => (
        <Link to={`/candidates/candidateProfile/${record.id}`}>{record.name}</Link>
      ),
      sorter: (a, b) => a.name.localeCompare(b.name)
    },
    // {
    //   title: "Job Title",
    //   dataIndex: "role",
    //   sorter: (a, b) => a.role.length - b.role.length,
    // },
    {
      title: 'Experience',
      dataIndex: 'experience'
    },
    {
      title: 'Location',
      dataIndex: 'location',
      sorter: (a, b) => a.location.localeCompare(b.location)
    },
    {
      title: 'Email',
      dataIndex: 'emailId'
    },
    {
      title: 'Phone',
      dataIndex: 'phone'
    }
  ]

  const data = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    legend: {
      display: false
    },
    datasets: [

      {
        label: 'UI Developer',
        data: [20, 10, 5, 5, 20],
        lineTension: 0.2,
        fill: false,
        borderColor: '#373651',
        backgroundColor: '#373651',
        borderWidth: 1
      },
      {
        label: 'Android',
        data: [2, 2, 3, 4, 1],
        fill: false,
        lineTension: 0.2,
        legend: false,
        borderColor: '#E65A26',
        backgroundColor: '#E65A26',
        borderWidth: 1
      },
      {
        label: 'Web Designing',
        data: [1, 3, 6, 8, 10],
        fill: false,
        lineTension: 0.2,
        borderColor: '#a1a1a1',
        backgroundColor: '#a1a1a1',
        borderWidth: 1
      }
    ]

  }
  return (
    <>
      {/* Page Wrapper */}
      <div className='page-wrapper'>
        <HelmetProvider>
          <div>
            <Helmet>
              <title>Job Dashboard - qBotica</title>
              <meta name='description' content='Login page' />
            </Helmet>
          </div>
        </HelmetProvider>

        {/* Page Content */}
        <div className='content container-fluid'>
          {/* Page Header */}
          <div className='page-header'>
            <div className='row'>
              <div className='col-sm-12'>
                {/* <marquee behavior="scroll" direction="right" style={{ backgroundColor: "black", color: "white" }}>The data displayed here is for only demo purposes...!</marquee> */}
                <h3 className='page-title'>Job Dashboard</h3>
              </div>
            </div>
          </div>
          {/* /Page Header */}
          <div className='row'>
            <div className='col-md-6 col-sm-6 col-lg-6 col-xl-3'>
              <div className='card dash-widget'>
                <div className='card-body'>
                  <span className='dash-widget-icon'><i className='fa fa-briefcase' /></span>
                  <div className='dash-widget-info'>
                    <h3>{totalJobs}</h3>
                    <span>Jobs</span>
                  </div>
                </div>
              </div>
            </div>
            <div className='col-md-6 col-sm-6 col-lg-6 col-xl-3'>
              <div className='card dash-widget'>
                <div className='card-body'>
                  <span className='dash-widget-icon'><i className='fa fa-users' /></span>
                  <div className='dash-widget-info'>
                    <h3>{totalCandidates}</h3>
                    <span>Job Seekers</span>
                  </div>
                </div>
              </div>
            </div>
            <div className='col-md-6 col-sm-6 col-lg-6 col-xl-3'>
              <div className='card dash-widget'>
                <div className='card-body'>
                  <span className='dash-widget-icon'><i className='fa fa-user' /></span>
                  <div className='dash-widget-info'>
                    <h3>{totalClients}</h3>
                    <span>Clients</span>
                  </div>
                </div>
              </div>
            </div>
            <div className='col-md-6 col-sm-6 col-lg-6 col-xl-3'>
              <div className='card dash-widget'>
                <div className='card-body'>
                  <span className='dash-widget-icon'><i className='fa fa-clipboard' /></span>
                  <div className='dash-widget-info'>
                    <h3>{totalCandidates}</h3>
                    <span>Applications</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-md-12'>
              <div className='row'>
                <div className='col-md-6 text-center d-flex'>
                  <div className='card flex-fill'>
                    <div className='card-body'>
                      <h3 className='card-title'>Overview</h3>
                      <Line data={data} />
                    </div>
                  </div>
                </div>
                <div className='col-md-6 d-flex'>
                  <div className='card flex-fill'>
                    <div className='card-body'>
                      <h3 className='card-title text-center'>Latest Jobs</h3>
                      <div className='table-responsive'>
                        <Table
                          className='table-striped'
                          style={{ overflowX: 'auto' }}
                          columns={columnsLastestJobs}
                          bordered
                          dataSource={jobsData}
                          pagination={false}
                          showHeader={!isEmpty}
                        // rowKey={record => record.id}
                        // onChange={this.handleTableChange}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-md-12'>
              <div className='card card-table'>
                <div className='card-header'>
                  <h3 className='card-title mb-0'>Jobs List</h3>
                </div>
                <div className='table-responsive'>
                  <Table
                    className='table-striped'
                    style={{ overflowX: 'auto' }}
                    columns={columnsJobs}
                    // bordered
                    dataSource={jobsData}
                    pagination={false}
                  // rowKey={record => record.id}
                  // onChange={this.handleTableChange}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-md-12'>
              <div className='card card-table'>
                <div className='card-header'>
                  <h3 className='card-title mb-0'>Candidates List</h3>
                </div>
                <div className='table-responsive'>
                  <Table
                    className='table-striped'
                    style={{ overflowX: 'auto' }}
                    columns={columnsCandidates}
                    // bordered
                    dataSource={candidatesData}
                    pagination={false}
                  // rowKey={record => record.id}
                  // onChange={this.handleTableChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /Page Content */}
      </div>
      {/* /Page Wrapper */}
    </>
  )
}

export default JobsDashboard
