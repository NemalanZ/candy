// candidatelist

import { DeleteTwoTone, EditTwoTone } from '@ant-design/icons'
import { Popconfirm, Space, Table } from 'antd'
import { Excel } from 'antd-table-saveas-excel'
import 'antd/dist/antd'
import React, { useEffect, useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useParams } from 'react-router-dom'
import { itemRender, onShowSizeChange } from '../../../paginationfunction'

const CandidateList = ({
  fetchAllCandidates,
  deleteCandidate,
  allCandidates,
  candidateStatus,
  fetchCandidatesStatus
}) => {
  const { id } = useParams
  const [gridData, setgridData] = useState([])
  const [page, setPage] = useState(1)

  useEffect(() => {
    fetchAllCandidates()
    fetchCandidatesStatus()
  }, [])

  useEffect(() => {
    if (Array.isArray(allCandidates)) {
      setgridData(allCandidates)
    }
  }, [allCandidates])

  const dataWithDetails = gridData.map((details, index) => ({
    ...details,
    key: index,
    id: details.candidate_id,
    name: `${details.first_name} ${details.last_name}`,
    // role: details.gridData.role,
    experience: `${details.experience}`,
    location: `${details.city_name}, ${details.state_name}`,
    emailId: details.email,
    phone: details.contact_no,
    rounds: details.selection_status_name,
    status: details.profile_status_name
  }))

  // console.log("data==>", dataWithDetails)

  const handleDelete = async (id) => {
    deleteCandidate(id)
  }

  const columns = [
    {
      title: 'Id',
      key: 'serial',
      dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Name',
      dataIndex: 'name',
      editTable: true,
      render: (_, record) => (
        <Link to={`candidateProfile/${record.id}`}>{record.name}</Link>
      ),
      sorter: (a, b) => a.name.localeCompare(b.name)
    },
    // {
    //   title: "Job Title",
    //   dataIndex: "role",
    //   sorter: (a, b) => a.role.length - b.role.length,
    // },
    {
      title: 'Experience',
      dataIndex: 'experience'
    },
    {
      title: 'Location',
      dataIndex: 'location',
      sorter: (a, b) => a.location.localeCompare(b.location)
    },
    {
      title: 'Email',
      dataIndex: 'emailId'
    },
    {
      title: 'Phone',
      dataIndex: 'phone'
    },
    // {
    //   title: 'Rounds',
    //   dataIndex: 'rounds'
    // },
    // {
    //   title: 'Status',
    //   dataIndex: 'status',
    //   render(text, record) {
    //     return {
    //       props: {
    //         style: {
    //           color:
    //             record.status === 'Selected'
    //               ? 'green'
    //               : record.status === 'Not Selected'
    //                 ? 'red'
    //                 : record.status === 'Decision Pending'
    //                   ? '#f3b800'
    //                   : 'white'
    //         }
    //       },
    //       children: <div>{text}</div>
    //     }
    //   },
    //   filters: [
    //     {
    //       text: 'Selected',
    //       value: 'Selected'
    //     },
    //     {
    //       text: 'Decision Pending',
    //       value: 'Decision Pending'
    //     },
    //     {
    //       text: 'Not Selected',
    //       value: 'Not Selected'
    //     }
    //   ],
    //   onFilter: (value, record) => record.status.indexOf(value) === 0,
    //   // filterMultiple: false
    // },
    {
      title: 'Action',
      dataIndex: 'action',
      render: (_, record) => (
        <Space>
          <Popconfirm
            title='Are you sure want to delete ?'
            onConfirm={() => {
              handleDelete(record.id)
            }}
          >
            <DeleteTwoTone style={{ color: 'red' }} />
          </Popconfirm>
          <Link to={`editCandidate/${record.id}`}>
            <EditTwoTone />
          </Link>
        </Space>
      )
    }
  ]

  const handleClick = () => {
    const excel = new Excel()
    excel
      .addSheet('test')
      .addColumns(columns.slice(0, 6))
      .addDataSource(dataWithDetails, {
        str2Percent: true
      })
      .saveAs('Excel.xlsx')
  }

  // const onChange: TableProps<DataType>['onChange'] = (pagination, filters, sorter, extra) => {
  //   console.log('params', pagination, filters, sorter, extra);
  // };

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        {/* Page Header */}
        <div className='page-header'>
          <div className='row align-items-center'>
            <div className='col'>
              <h3 className='page-title'>Candidate</h3>
              <ul className='breadcrumb'>
                <li className='breadcrumb-item'>
                  <Link to='/dashboard'>Dashboard</Link>
                </li>
                <li className='breadcrumb-item'>Candidates</li>
              </ul>
            </div>
            <div className='col-auto float-end ml-auto'>
              <button className='btn export-btn' onClick={handleClick}>
                <i className='fa-regular fa-file-excel' />
                Export
              </button>
            </div>
            <div className='col-auto float-end ml-auto'>
              <Link to='addCandidate' className='btn add-btn'>
                <i className='fa fa-plus' />
                Add
              </Link>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        <div className='row'>
          <div className='col-md-12'>
            <div className='table-responsive'>
              <Table
                className='table-striped'
                pagination={{
                  total: dataWithDetails.length,
                  showTotal: (total, range) =>
                    `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                  showSizeChanger: true,
                  onShowSizeChange,
                  itemRender,
                  onChange(current) {
                    setPage(current)
                  }
                }}
                style={{ overflowX: 'auto' }}
                columns={columns}
                // bordered
                dataSource={dataWithDetails}

              // rowKey={record => record.id}
              // onChange={onChange}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CandidateList
