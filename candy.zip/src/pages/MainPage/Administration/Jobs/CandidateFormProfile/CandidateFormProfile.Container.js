import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import {
  fetchCandidateDetails,
  getCandidateId,
  getFirstName,
  getLastName,
  getGender,
  getEmailId,
  getPhone,
  getExperience,
  getMainSkill,
  getSecondarySkill,
  getAddress,
  getCity,
  getPinCode,
  getStateValue,
  getCountry,
  getResume,
  getJobTitle,
  getAppliedJobs,
  getCandidateRounds,
  getCandidateStatus,
  fetchMasterData
} from '../../../../../redux/reducers/candidateDetailsReducer'
// import { getCandidateRounds, getCandidateStatus, fetchMasterData } from '../../../../../redux/reducers/addCandidateReducer'
import Component from './CandidateFormProfile.Component'

const mapStateToProps = createStructuredSelector({
  candidateId: getCandidateId,
  firstName: getFirstName,
  lastName: getLastName,
  gender: getGender,
  emailId: getEmailId,
  phone: getPhone,
  experience: getExperience,
  mainSkill: getMainSkill,
  secondarySkill: getSecondarySkill,
  address: getAddress,
  city: getCity,
  pinCode: getPinCode,
  state: getStateValue,
  country: getCountry,
  resume: getResume,
  jobTitle: getJobTitle,
  candidateRounds: getCandidateRounds,
  candidateStatus: getCandidateStatus,
  appliedJobs: getAppliedJobs,
})

const mapDispatchToProps = {
  fetchCandidateDetails,
  fetchMasterData,
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
