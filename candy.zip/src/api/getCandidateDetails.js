import axios from './getAxios'

export default async (id) => {
  const { data } = await axios({
    method: 'GET',
    url: `candidateDetails/getCandidateDetails?candidate_id=${id}`
  })
  return data
}
