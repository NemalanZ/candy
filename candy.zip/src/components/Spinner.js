import React from 'react'
import { LoadingOutlined } from '@ant-design/icons'
import { Spin } from 'antd'
const antIcon = (
  <div style={{
    position: 'absolute',
    top: '0',
    bottom: '0',
    left: '0',
    right: '0',
    margin: 'auto'
  }}
  >
    <LoadingOutlined
      style={{
        fontSize: 30
      }}
      spin
    />
  </div>
)
const Spinner = () => <Spin indicator={antIcon} />
export default Spinner
