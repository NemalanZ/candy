import axios from './getAxios'

export default async (id) => {
  const { data } = await axios({
    method: 'DELETE',
    url: `candidateDetails/deleteSpecificCandidate?candidate_id=${id}`
  })
  return data
}
