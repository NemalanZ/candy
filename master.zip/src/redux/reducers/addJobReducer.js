import { defaultTo, equals, filter, find, prop, propEq } from 'ramda'
import { createSelector } from 'reselect'
import getClientsApi from '../../api/getClient'
import getClientAddressApi from '../../api/getClientAddress'
import getJobTypesApi from '../../api/getJobType'
import postJobApi from '../../api/postJob'
import { POST_JOB_ACTION as ACTIONS } from '../actions'

const initialState = {
  error: null,
  loading: false,
  requisitionId: createUUID(),
  dateOfRequisition: '',
  jobTitle: '',
  jobType: '',
  jobStatus: '',
  client: '',
  address: '',
  city: '',
  pinCode: '',
  country: '',
  state: '',
  experience: '',
  vacancyCount: '',
  minSalary: '',
  maxSalary: '',
  jobDescriptionFilePath: '',
  jobDescriptionText: '',
  archived: false,

  jobTypes: [],
  clients: [],
  clientAddress: [],
  selectedClient: []
  // companies: [],
  // cities: [],
  // states: [],
  // countries: [],
}

function createUUID () {
  const value = Math.floor(1000 + Math.random() * 9000)
  return value
}

const getSlice = prop('addJob')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getRequisitionId = createSelector(getSlice, prop('requisitionId'))
export const getDateOfRequisition = createSelector(getSlice, prop('dateOfRequisition'))
export const getJobTitle = createSelector(getSlice, prop('jobTitle'))
export const getJobType = createSelector(getSlice, prop('jobType'))
export const getJobStatus = createSelector(getSlice, prop('jobStatus'))
export const getClient = createSelector(getSlice, prop('client'))
export const getAddress = createSelector(getSlice, prop('address'))
export const getCity = createSelector(getSlice, prop('city'))
export const getPinCode = createSelector(getSlice, prop('pinCode'))
export const getStateValue = createSelector(getSlice, prop('state'))
export const getCountry = createSelector(getSlice, prop('country'))
export const getExperience = createSelector(getSlice, prop('experience'))
export const getVacancyCount = createSelector(getSlice, prop('vacancyCount'))
export const getMinSalary = createSelector(getSlice, prop('minSalary'))
export const getMaxSalary = createSelector(getSlice, prop('maxSalary'))
export const getJobDescriptionFilePath = createSelector(getSlice, prop('jobDescriptionFilePath'))
export const getJobDescriptionText = createSelector(getSlice, prop('jobDescriptionText'))
export const getArchived = createSelector(getSlice, prop('archived'))

// MASTER TABLE
export const getJobTypes = createSelector(getSlice, prop('jobTypes'))
export const getClients = createSelector(getSlice, prop('clients'))
export const getClientAddress = createSelector(getSlice, prop('clientAddress'))
export const getSelectedClient = createSelector(getSlice, prop('selectedClient'))
// export const getCompanies = createSelector(getSlice, prop('companies'));
// export const getCities = createSelector(getSlice, prop('cities'));
// export const getStates = createSelector(getSlice, prop('states'));
// export const getCountries = createSelector(getSlice, prop('countries'));

export const postJob = (navigate) => async (dispatch, getState) => {
  dispatch({
    type: ACTIONS.POST_JOB_REQUEST
  })
  try {
    const payload = {
      requisition_id: getRequisitionId(getState()),
      date_of_requisition: getDateOfRequisition(getState()),
      job_title: getJobTitle(getState()),
      job_type: getJobType(getState()),
      job_status: getJobStatus(getState()),
      client: getClient(getState()),
      address: getAddress(getState()),
      city_id: getCity(getState()),
      pin_code: getPinCode(getState()),
      state_id: getStateValue(getState()),
      country_id: getCountry(getState()),
      experience: getExperience(getState()),
      vacancy_count: getVacancyCount(getState()),
      min_salary: getMinSalary(getState()),
      max_salary: getMaxSalary(getState()),
      job_description_file_path: getJobDescriptionFilePath(getState()),
      job_description_text: getJobDescriptionText(getState()),
      archived: getArchived(getState())
    }
    const postJobData = await postJobApi(payload)
    // console.log(postJobData);
    dispatch({
      type: ACTIONS.POST_JOB_SUCCESS,
      data: postJobData,
      payload
    })
    if (equals(' Job Posting saved successfully ', prop('response_message', postJobData))) {
      navigate('/jobs')
    } else {
      dispatch({
        type: ACTIONS.POST_JOB_FAILURE,
        error: postJobData.response_message
      })
    }
  } catch (error) {
    dispatch({
      type: ACTIONS.POST_JOB_FAILURE,
      error
    })
  }
}

export const fetchMasterData = () => async (dispatch) => {
  dispatch({
    type: ACTIONS.JOB_MASTER_DATA_ACTION_REQUEST
  })
  try {
    const jobTypesData = await getJobTypesApi()
    const clientsData = await getClientsApi()
    const clientAddressData = await getClientAddressApi()
    // const citiesData = await getCitiesApi();
    // const statesData = await getStatesApi();
    // const countriesData = await getCountriesApi();

    const data = {
      jobTypesData,
      clientsData,
      clientAddressData
      // citiesData,
      // statesData,
      // countriesData,
    }
    // console.log('masterData', data)
    dispatch({
      type: ACTIONS.JOB_MASTER_DATA_ACTION_SUCCESS,
      masterData: data
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.JOB_MASTER_DATA_ACTION_FAILURE,
      error
    })
  }
}

export const setRequisitionId = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_REQUISITION_ID,
    value: defaultTo('', value)
  })
}
export const setDateOfRequisition = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_DATE_OF_REQUISITION,
    value: defaultTo('', value)
  })
}
export const setJobTitle = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_TITLE,
    value: defaultTo('', value)
  })
}
export const setJobType = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_TYPE,
    value: defaultTo('', value)
  })
}
export const setJobStatus = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_STATUS,
    value: defaultTo('', value)
  })
}
export const setClient = (value) => (dispatch, getState) => {
  const clientAddresses = getClientAddress(getState())
  const findClientDetails = filter(propEq('client_id', Number(value)), clientAddresses)
  // console.log("clientAddresses===>", clientAddresses)
  // console.log("findClientDetails===>", findClientDetails)
  // console.log("values===>", value)
  dispatch({
    type: ACTIONS.SET_CLIENT,
    value: defaultTo('', value),
    details: findClientDetails
  })
}
export const setAddress = (value) => (dispatch, getState) => {
  const selectedClient = getSelectedClient(getState())
  const findClientAdress = find(propEq('address', value), selectedClient)
  console.log('selectedClient==>', selectedClient)
  dispatch({
    type: ACTIONS.SET_ADDRESS,
    value: defaultTo('', value),
    details: findClientAdress
  })
}
export const setCity = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_CITY,
    value: defaultTo('', value)
  })
}
export const setPinCode = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_PIN_CODE,
    value: defaultTo('', value)
  })
}
export const setState = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_STATE,
    value: defaultTo('', value)
  })
}
export const setCountry = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_COUNTRY,
    value: defaultTo('', value)
  })
}
export const setExperience = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_EXPERIENCE,
    value: defaultTo('', value)
  })
}
export const setVacancyCount = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_VACANCY_COUNT,
    value: defaultTo('', value)
  })
}
export const setMinSalary = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_MIN_SALARY,
    value: defaultTo('', value)
  })
}
export const setMaxSalary = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_MAX_SALARY,
    value: defaultTo('', value)
  })
}
export const setJobDescriptionFilePath = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_DESCRIPTION_FILE_PATH,
    value: defaultTo('', value)
  })
}
export const setJobDescriptiontext = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_DESCRIPTION_TEXT,
    value: defaultTo('', value)
  })
}
export const setArchived = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_ARCHIVED,
    value: defaultTo('', value)
  })
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.JOB_MASTER_DATA_ACTION_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.JOB_MASTER_DATA_ACTION_SUCCESS:
      return {
        ...state,
        masterData: action.masterData,
        jobTypes: action.masterData.jobTypesData,
        clients: action.masterData.clientsData,
        clientAddress: action.masterData.clientAddressData,
        // selectedClient: action.details,
        // companies: pipe(
        //   pluck('company_name'),
        //   uniq,
        // )(action.masterData.clientAddressData),
        // cities: action.masterData.citiesData,
        // states: action.masterData.statesData,
        // countries: action.masterData.countriesData,
        loading: false,
        error: false
      }
    case ACTIONS.JOB_MASTER_DATA_ACTION_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.POST_JOB_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.POST_JOB_SUCCESS: {
      return {
        ...state,
        requisitionId: prop('requisitionId', action.data),
        dateOfRequisition: prop('dateOfRequisition', action.data),
        jobTitle: prop('jobTitle', action.data),
        jobType: prop('jobType', action.data),
        jobStatus: prop('jobStatus', action.data),
        client: prop('client', action.data),
        address: prop('address', action.data),
        city: prop('city', action.data),
        pinCode: prop('pinCode', action.data),
        state: prop('state', action.data),
        country: prop('country', action.data),
        experience: prop('experience', action.data),
        vacancyCount: prop('vacancyCount', action.data),
        minSalary: prop('minSalary', action.data),
        maxSalary: prop('maxSalary', action.data),
        jobDescriptionFilePath: prop('jobDescriptionFilePath', action.data),
        jobDescriptionText: prop('jobDescriptionText', action.data),
        archived: prop('archived', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.POST_JOB_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.SET_REQUISITION_ID: {
      return {
        ...state,
        requisitionId: action.value
      }
    }
    case ACTIONS.SET_DATE_OF_REQUISITION: {
      return {
        ...state,
        dateOfRequisition: action.value
      }
    }
    case ACTIONS.SET_JOB_TITLE: {
      return {
        ...state,
        jobTitle: action.value
      }
    }
    case ACTIONS.SET_JOB_TYPE: {
      return {
        ...state,
        jobType: action.value
      }
    }
    case ACTIONS.SET_JOB_STATUS: {
      return {
        ...state,
        jobStatus: action.value
      }
    }
    case ACTIONS.SET_CLIENT: {
      return {
        ...state,
        client: action.value,
        selectedClient: action.details,
        address: '',
        pinCode: '',
        city: '',
        state: '',
        country: ''
      }
    }
    case ACTIONS.SET_ADDRESS: {
      return {
        ...state,
        address: action.value,
        pinCode: prop('pin_code', action.details),
        city: prop('city_id', action.details),
        state: prop('state_id', action.details),
        country: prop('country_id', action.details)
      }
    }
    case ACTIONS.SET_CITY: {
      return {
        ...state,
        city: action.value
      }
    }
    case ACTIONS.SET_PIN_CODE: {
      return {
        ...state,
        pinCode: action.value
      }
    }
    case ACTIONS.SET_STATE: {
      return {
        ...state,
        state: action.value
      }
    }
    case ACTIONS.SET_COUNTRY: {
      return {
        ...state,
        country: action.value
      }
    }
    case ACTIONS.SET_EXPERIENCE: {
      return {
        ...state,
        experience: action.value
      }
    }
    case ACTIONS.SET_VACANCY_COUNT: {
      return {
        ...state,
        vacancyCount: action.value
      }
    }
    case ACTIONS.SET_MIN_SALARY: {
      return {
        ...state,
        minSalary: action.value
      }
    }
    case ACTIONS.SET_MAX_SALARY: {
      return {
        ...state,
        maxSalary: action.value
      }
    }
    case ACTIONS.SET_JOB_DESCRIPTION_FILE_PATH: {
      return {
        ...state,
        jobDescriptionFilePath: action.value
      }
    }
    case ACTIONS.SET_JOB_DESCRIPTION_TEXT: {
      return {
        ...state,
        jobDescriptionText: action.value
      }
    }
    case ACTIONS.SET_ARCHIVED: {
      return {
        ...state,
        archived: action.value
      }
    }
    default:
      return initialState
  }
}
