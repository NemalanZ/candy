function setTempEmailId (emailId) {
  return window.localStorage.setItem('tempEmailId', JSON.stringify(emailId))
}
function clearTempEmailId () {
  return window.localStorage.removeItem('tempEmailId')
}
function getTempEmailId () {
  return JSON.parse(window.localStorage.getItem('tempEmailId'))
}

export { setTempEmailId, clearTempEmailId, getTempEmailId }
