import { UploadOutlined } from '@ant-design/icons'
import { Button, DatePicker, Input, Select, Space, Upload } from 'antd'
import JoditEditor from 'jodit-react'
import { head, length, map, prop } from 'ramda'
import React, { useEffect, useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate } from 'react-router-dom'
import uploadFileToBlob, {
  getBlobsInContainer,
  isStorageConfigured,
} from '../../../../../utils/storageBlobService'

const AddJob = ({
  postJob,
  requisitionId,
  dateOfRequisition,
  jobTitle,
  jobType,
  jobStatus,
  client,
  address,
  city,
  pinCode,
  state,
  country,
  experience,
  vacancyCount,
  minSalary,
  maxSalary,
  jobDescriptionFilePath,
  jobDescriptionText,
  archived,
  setRequisitionId,
  setDateOfRequisition,
  setJobTitle,
  setJobType,
  setJobStatus,
  setClient,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setExperience,
  setVacancyCount,
  setMinSalary,
  setMaxSalary,
  setJobDescriptionFilePath,
  setJobDescriptiontext,
  setArchived,
  fetchMasterData,
  jobTypes,
  clients,
  cities,
  states,
  countries,
  clientAddress,
  // companies,
  selectedClient,
}) => {
  const navigate = useNavigate()
  const [placement, SetPlacement] = useState('bottomRight')

  useEffect(() => {
    fetchMasterData()
    const storageConfigured = isStorageConfigured()
    console.log('isStorageConfigrers', storageConfigured)
  }, [])

  useEffect(() => {
    if (length(selectedClient) === 1) {
      const selectedItem = head(selectedClient)
      setAddress(prop('address', selectedItem))
      setPinCode(prop('pin_code', selectedItem))
      setCity(prop('city_id', selectedItem))
      setState(prop('state_id', selectedItem))
      setCountry(prop('country_id', selectedItem))
    }
  }, [selectedClient])

  console.log('address:', selectedClient)

  const handleSubmit = (e) => {
    e.preventDefault()
    postJob(navigate)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Add job - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Create Job</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'>
                      <Link to='/jobs'>Jobs</Link>
                    </li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <form>
              <div className='row'>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>
                      Requisition ID
                      <span style={{ color: 'red' }}>*</span>
                    </label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='requisitionId'
                      type='text'
                      value={requisitionId}
                      onChange={(e) => setRequisitionId(e.target.value)}
                      disabled
                    />
                  </div>
                </div>
                <div className='col-sm-6'>
                  <div className='form-group'>
                    <label>
                      Date of Requisition<span style={{ color: 'red' }}>*</span>
                    </label>
                    <DatePicker
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      value={dateOfRequisition}
                      onChange={(value) => setDateOfRequisition(value)}
                      rules={[
                        { required: true, message: 'Please select date!' },
                      ]}
                      placement='bottomRight'
                    />
                  </div>
                </div>
              </div>
              <div
                style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}
              >
                <h4 style={{ color: '#ff8010' }}>Job Details</h4>
              </div>
              <div className='row'>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>
                      Job Title
                      <span style={{ color: 'red' }}>*</span>
                    </label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='jobTitle'
                      type='text'
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>
                      Job Type
                      <span style={{ color: 'red' }}>*</span>
                    </label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      placeholder='Select'
                      name='jobType'
                      // value={jobType}
                      onChange={(value) => setJobType(value)}
                      options={map(
                        (item) => ({
                          value: item.job_type_id,
                          label: item.job_type_name,
                        }),
                        jobTypes
                      )}
                    />
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>
                      Job Status<span style={{ color: 'red' }}>*</span>
                    </label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='jobStatus'
                      placeholder='Select'
                      // value={jobStatus}
                      onChange={(value) => setJobStatus(value)}
                      options={[
                        { value: 'Open', label: 'Open' },
                        { value: 'On Hold', label: 'On Hold' },
                        { value: 'Closed', label: 'Closed' },
                      ]}
                    />
                  </div>
                </div>
              </div>
              <div
                style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}
              >
                <h4 style={{ color: '#ff8010' }}>Client Details</h4>
              </div>
              <div className='row'>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>
                      Client
                      <span style={{ color: 'red' }}>*</span>
                    </label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='client'
                      placeholder='Select'
                      // value={client}
                      onChange={(value) => {
                        setClient(value)
                      }}
                    >
                      <option defaultValue='Select' hidden>
                        {' '}
                        Select{' '}
                      </option>
                      {clients.map((get, index) => (
                        <option key={index.toString()} value={get.client_id}>
                          {' '}
                          {get.company_name}
                        </option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>
                      Location
                      <span style={{ color: 'red' }}>*</span>
                    </label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='location'
                      value={address}
                      placeholder='Select'
                      options={map(
                        (item) => ({
                          value: item.address,
                          label: item.address,
                        }),
                        selectedClient
                      )}
                      onChange={(value) => {
                        setAddress(value)
                      }}
                    />
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Postal Code</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='pinCode'
                      type='number'
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                      disabled
                    />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>City</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='city'
                      placeholder='Select'
                      value={city}
                      onChange={(value) => setCity(value)}
                      options={map(
                        (item) => ({
                          value: item.city_id,
                          label: item.city_name,
                        }),
                        clientAddress
                      )}
                      disabled
                    />
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>State</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='state'
                      placeholder='Select'
                      value={state}
                      onChange={(value) => setState(value)}
                      options={map(
                        (item) => ({
                          value: item.state_id,
                          label: item.state_name,
                        }),
                        clientAddress
                      )}
                      disabled
                    />
                  </div>
                </div>
                <div className='col-sm-4'>
                  <div className='form-group'>
                    <label>Country</label>
                    <Select
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='country'
                      placeholder='Select'
                      value={country}
                      onChange={(value) => setCountry(value)}
                      options={map(
                        (item) => ({
                          value: item.country_id,
                          label: item.country_name,
                        }),
                        clientAddress
                      )}
                      disabled
                    />
                  </div>
                </div>
              </div>
              <div
                style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}
              >
                <h4 style={{ color: '#ff8010' }}>Candidate Expertise</h4>
              </div>
              <div className='row'>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Year of Experience</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='experience'
                      type='text'
                      value={experience}
                      onChange={(e) => setExperience(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Vacancy</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='vacancyCount'
                      type='number'
                      value={vacancyCount}
                      onChange={(e) => setVacancyCount(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Minimum Rate</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='minSalary'
                      type='number'
                      value={minSalary}
                      onChange={(e) => setMinSalary(e.target.value)}
                    />
                  </div>
                </div>
                <div className='col-sm-3'>
                  <div className='form-group'>
                    <label>Maximum Rate</label>
                    <Input
                      size='large'
                      style={{
                        width: '100%',
                      }}
                      name='maxSalary'
                      type='number'
                      value={maxSalary}
                      onChange={(e) => setMaxSalary(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div
                style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}
              >
                <h4 style={{ color: '#ff8010' }}>Job Description</h4>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <label>Upload file</label>
                    <Space
                      direction='horizontal'
                      size='middle'
                      style={{ paddingLeft: '10px' }}
                    >
                      <Upload
                        listType='picture'
                        value={jobDescriptionFilePath}
                        onChange={
                          (value) => {
                            uploadFileToBlob(value.file)
                            // getBlobsInContainer()
                          }
                          // setJobDescriptionFilePath(value)
                        }
                      >
                        <Button icon={<UploadOutlined />}>
                          Click to upload
                        </Button>
                      </Upload>
                    </Space>
                    {/* <input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      value={jobDescriptionFilePath}
                      onChange={value => setJobDescriptionFilePath(value)}
                      accept='.pdf'
                    /> */}
                    {/* <FileBase64
                      type="file"
                      multiple={false}
                      onDone={({ base64 }) => setJobDescriptionFilePath(base64)}
                    /> */}
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-sm-12'>
                  <div className='form-group'>
                    <p style={{ textAlign: 'center' }}>(or)</p>
                    <JoditEditor
                      value={jobDescriptionText}
                      onChange={(jobDescriptionText) =>
                        setJobDescriptiontext(jobDescriptionText)
                      }
                    />
                  </div>
                </div>
              </div>
              <div className='row' />

              <div className='submit-section'>
                <button
                  type='button'
                  className='btn btn-primary submit-btn'
                  onClick={handleSubmit}
                >
                  Save
                </button>
                <button
                  type='button'
                  className='btn btn-dark submit-btn'
                  onClick={() => navigate('/jobs')}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default AddJob
