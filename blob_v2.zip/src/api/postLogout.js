import axios from './getAxios'
// import { encode } from 'js-base64';
import { storeSession } from '../utils/sessionUtils'

export default async () => {
  // console.log('emailId, pass', email, password)
  const { data } = await axios({
    method: 'POST',
    url: 'Auth/Logout',
  })
  storeSession(data)
  return data
}
