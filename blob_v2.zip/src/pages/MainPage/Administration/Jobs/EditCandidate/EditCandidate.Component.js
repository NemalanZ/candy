import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate, useParams, useLocation } from 'react-router-dom'
import {
  Select, DatePicker, Input, Upload, Button, Space, Form, Row, Col
} from 'antd'
import { map, pick, project, pluck } from 'ramda'
import { UploadOutlined } from '@ant-design/icons'
import logger from 'redux-logger'
import ColumnGroup from 'antd/es/table/ColumnGroup'

const EditCandidate = ({
  fetchPrevCandidateDetails,
  candidateId,
  firstName,
  lastName,
  gender,
  emailId,
  phone,
  experience,
  mainSkill,
  secondarySkill,
  address,
  city,
  pinCode,
  state,
  country,
  resume,
  fetchMasterData,
  skills,
  cities,
  states,
  countries,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setResume,
  putCandidate,
  candidateDetails,
  jobId,
  jobTitle,
  candidateRounds,
  candidateStatus,
  setJobTitle,
  setRounds,
  setStatus,
  rounds,
  status,
  jobDetails,
  jobData,
}) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const options = map(item => ({ value: item.job_id, label: item.job_title }), jobDetails)

  console.log("jobData==>", jobData)

  const [form] = Form.useForm();
  const initialValues = {
    jobId,
    firstName,
    lastName,
    gender,
    emailId,
    phone,
    experience,
    mainSkill,
    secondarySkill,
    address,
    city,
    pinCode,
    state,
    country,
    resume,
    jobData,
  };

  useEffect(() => {
    form.setFieldsValue(initialValues);
  }, [form, initialValues]);

  useEffect(() => {
    fetchMasterData()
    fetchPrevCandidateDetails(location.state)
  }, [location.state])

  const handleSubmit = () => {
    putCandidate(location.state, navigate)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Edit Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Edit Candidate</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'><Link to='/candidates'>Candidates</Link></li>
                    <li className='breadcrumb-item'>Edit Candidate</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* Page Header */}
            <Form
              form={form}
              name="formJob"
              layout={'vertical'}
              style={{ maxWidth: '100%' }}
              colon={false}
              onFinish={handleSubmit}
            >
              <Row gutter={16}>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12}>
                  <Form.Item
                    name='jobData'
                    label='Job Title'
                  >
                    <Select
                      size='large'
                      mode='multiple'
                      allowClear
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={value => setJobTitle(value)}
                      options={options}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12} >
                  <Form.Item
                    name="gender"
                    label='Gender'
                    rules={[
                      {
                        required: true,
                        message: 'Gender required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={(value) => setGender(value)}
                      options={[
                        { value: 'Male', label: 'Male' },
                        { value: 'Female', label: 'Female' }
                      ]}
                      status={gender || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    name='firstName'
                    label='First Name'
                    rules={[
                      {
                        required: true,
                        message: 'First Name required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      onChange={(e) => setFirstName(e.target.value)}
                      status={firstName || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    name='lastName'
                    label='Last Name'
                    rules={[
                      {
                        required: true,
                        message: 'Last Name required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      onChange={(e) => setLastName(e.target.value)}
                      status={lastName || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Contact</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    name='emailId'
                    label='Email'
                    rules={[
                      {
                        required: true,
                        message: 'Email required',
                      },
                      {
                        pattern: "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",
                        message: "Invalid Email (examplemail@gmail.com)",
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='email'
                      onChange={(e) => setEmailId(e.target.value)}
                      status={emailId || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    name='phone'
                    label='Phone'
                    rules={[
                      {
                        required: true,
                        message: 'Phone required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='number'
                      onChange={(e) => setPhone(e.target.value)}
                      status={phone || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Address</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <Form.Item
                    name="address"
                    label='Address'
                    rules={[
                      {
                        required: true,
                        message: 'Address required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      onChange={(e) => setAddress(e.target.value)}
                      status={address || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    name='pinCode'
                    label='Pin Code'
                    rules={[
                      {
                        required: true,
                        message: 'Pin Code required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='number'
                      onChange={(e) => setPinCode(e.target.value)}
                      status={pinCode || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    name='city'
                    label='City'
                    rules={[
                      {
                        required: true,
                        message: 'City required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={(value) => {
                        setCity(value)
                      }}
                      options={map(item => ({ value: item.city_id, label: item.city_name }), cities)}
                      status={city || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    name='state'
                    label='State'
                    rules={[
                      {
                        required: true,
                        message: 'State required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={(value) => setState(value)}
                      options={map(item => ({ value: item.state_id, label: item.state_name }), states)}
                      status={state || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    name='country'
                    label='Country'
                    rules={[
                      {
                        required: true,
                        message: 'Country required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={(value) => setCountry(value)}
                      options={map(item => ({ value: item.country_id, label: item.country_name }), countries)}
                      status={country || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Experience & Skills</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    name='experience'
                    label='Year of Experience'
                    rules={[
                      {
                        required: true,
                        message: 'Year of Experience required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      onChange={(e) => setExperience(e.target.value)}
                      status={experience || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    name='mainSkill'
                    label='Main Skill'
                    rules={[
                      {
                        required: true,
                        message: 'Main Skill required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      onChange={(value) => setMainSkill(value)}
                      options={map(item => ({ value: item.skill_id, label: item.skill_name }), skills)}
                      status={mainSkill || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    name='secondarySkill'
                    label='Secondary Skill'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      onChange={(e) => setSecondarySkill(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Resume</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <Form.Item
                    name='resume'
                    label='Upload File'
                  // rules={[
                  //   {
                  //     required: true,
                  //     message: 'Upload File required',
                  //   },
                  // ]}
                  >
                    <Upload
                      listType="picture"
                    // value={resume}
                    // onChange={(value) => setResume(value)}
                    >
                      <Button icon={<UploadOutlined />}>Click to upload</Button>
                    </Upload>
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <div className='submit-section'>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      htmlType="submit"
                      className='btn btn-primary submit-btn'
                    // onClick={handleSubmit}
                    >Save
                    </Button>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      className='btn btn-dark submit-btn'
                      type="button"
                      onClick={() => navigate('/candidates')}
                    >Cancel
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default EditCandidate
