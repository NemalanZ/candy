import { DeleteOutlined, EditOutlined, FileExcelOutlined } from '@ant-design/icons'
import { Popconfirm, Space, Table } from 'antd'
import { Excel } from 'antd-table-saveas-excel'
import 'antd/dist/antd'
import React, { useEffect, useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useParams, useLocation } from 'react-router-dom'
import { itemRender, onShowSizeChange } from '../../../Paginationfunction'
import { CSVLink } from 'react-csv'
import { project } from 'ramda'
import { Spinner } from 'react-bootstrap'

const CandidateList = ({
  fetchAllCandidates,
  deleteCandidate,
  allCandidates,
  candidateStatus,
  fetchCandidatesStatus,
  loading,
}) => {
  const { id } = useParams
  const location = useLocation()
  const [gridData, setgridData] = useState([])
  const [page, setPage] = useState(1)
  const [filteredInfo, setFilteredInfo] = useState({});
  const [sortedInfo, setSortedInfo] = useState({});

  const exportCandidates = project(['candidate_id', 'first_name', 'last_name', 'email', 'contact_no', 'city_name', 'state_name', 'experience'], allCandidates)

  const handleChange = (pagination, filters, sorter) => {
    console.log('Various parameters', pagination, filters, sorter);
    setFilteredInfo(filters);
    setSortedInfo(sorter);
  };

  useEffect(() => {
    fetchAllCandidates(location.state)
    fetchCandidatesStatus()
  }, [location.state])

  useEffect(() => {
    if (Array.isArray(allCandidates)) {
      setgridData(allCandidates)
    }
  }, [allCandidates])

  const dataWithDetails = gridData.map((details, index) => {
    return {
      ...details,
      key: index,
      id: details.candidate_id,
      name: `${details.first_name} ${details.last_name}`,
      // role: details.gridData.role,
      experience: `${details.experience}`,
      location: `${details.city_name}, ${details.state_name}`,
      emailId: details.email,
      phone: details.contact_no,
      rounds: details.selection_status_name,
      status: details.profile_status_name
    }
  })

  const handleDelete = async (id) => {
    deleteCandidate(id)
  }

  const columns = [
    {
      title: 'Id',
      key: 'serial',
      dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Name',
      dataIndex: 'name',
      editTable: true,
      render: (_, record) => (
        <Link
          to='candidateProfile'
          state={record.id}
        > {record.name}
        </Link>
      ),
      sorter: (a, b) => a.name.localeCompare(b.name)
    },
    {
      title: 'Email',
      dataIndex: 'emailId',
      sorter: (a, b) => a.emailId.localeCompare(b.emailId)
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      sorter: (a, b) => a.phone - b.phone
    },
    {
      title: 'Location',
      dataIndex: 'location',
      sorter: (a, b) => a.location.localeCompare(b.location)
    },
    {
      title: 'Experience',
      dataIndex: 'experience',
      sorter: (a, b) => {
        const aNum = parseInt(a.experience);
        const bNum = parseInt(b.experience);
        if (isNaN(aNum) && isNaN(bNum)) {
          return a.experience.localeCompare(b.experience);
        }
        if (isNaN(aNum)) {
          return 1;
        }
        if (isNaN(bNum)) {
          return -1;
        }
        return aNum - bNum;
      },
    },
    // {
    //   title: 'Rounds',
    //   dataIndex: 'rounds'
    // },
    // {
    //   title: 'Status',
    //   dataIndex: 'status',
    //   render(text, record) {
    //     return {
    //       props: {
    //         style: {
    //           color:
    //             record.status === 'Selected'
    //               ? 'green'
    //               : record.status === 'Not Selected'
    //                 ? 'red'
    //                 : record.status === 'Decision Pending'
    //                   ? '#f3b800'
    //                   : 'white'
    //         }
    //       },
    //       children: <div>{text}</div>
    //     }
    //   },
    //   filters: [
    //     {
    //       text: 'Selected',
    //       value: 'Selected'
    //     },
    //     {
    //       text: 'Decision Pending',
    //       value: 'Decision Pending'
    //     },
    //     {
    //       text: 'Not Selected',
    //       value: 'Not Selected'
    //     }
    //   ],
    //   onFilter: (value, record) => record.status.indexOf(value) === 0
    //   // filterMultiple: false
    // },
    {
      title: 'Action',
      dataIndex: 'action',
      render: (_, record) => (
        <Space>
          <Link to='editCandidate' state={record.id}>
            <EditOutlined style={{ fontSize: '1rem' }} />
          </Link>
          <Popconfirm
            title='Are you sure want to delete ?'
            onConfirm={() => {
              handleDelete(record.id)
            }}
          >
            <DeleteOutlined style={{ color: 'red', fontSize: '1rem' }} />
          </Popconfirm>
        </Space>
      )
    }
  ]

  const handleClick = () => {
    const excel = new Excel()
    excel
      .addSheet('test')
      .addColumns(columns.slice(0, 6))
      .addDataSource(dataWithDetails, {
        str2Percent: true
      })
      .saveAs('Excel.xlsx')
  }

  // const onChange: TableProps<DataType>['onChange'] = (pagination, filters, sorter, extra) => {
  //   console.log('params', pagination, filters, sorter, extra);
  // };

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        {/* Page Header */}
        <div className='page-header'>
          <div className='row align-items-center'>
            <div className='col'>
              <h3 className='page-title'>Candidates</h3>
              <ul className='breadcrumb'>
                <li className='breadcrumb-item'>
                  <Link to='/dashboard'>Dashboard</Link>
                </li>
                <li className='breadcrumb-item'>Candidates</li>
              </ul>
            </div>
            <div className='col-auto float-end ml-auto'>
              <button className='btn export-btn'>
                <CSVLink
                  data={exportCandidates}
                  // headers={columns}
                  onClick={() => {
                    console.log("clicked")
                  }}
                  style={{
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <FileExcelOutlined style={{ paddingRight: '3px' }} />
                  Export
                </CSVLink>
              </button>
              {/* <button className='btn export-btn' onClick={handleClick}>
                <i className='fa-regular fa-file-excel' />
                Export
              </button> */}
            </div>
            <div className='col-auto float-end ml-auto'>
              <Link to='addCandidate' className='btn add-btn'>
                <i className='fa fa-plus' />
                Add
              </Link>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        <div className='row'>
          <div className='col-md-12'>
            <div className='table-responsive'>
              {/* {!loading ? (
                <div className='center-screen'>
                  <Spinner
                    as="span"
                    animation="border"
                    size="sm"
                    role="status"
                    aria-hidden="true"
                    style={{ width: "1.2rem", height: "1.2rem", marginRight: "0.3rem" }}
                  />
                </div>
              ) :} */}
              <Table
                className='table-striped'
                pagination={{
                  // total: dataWithDetails.length,
                  // showTotal: (total, range) =>
                  //   `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                  showSizeChanger: true,
                  onShowSizeChange,
                  itemRender,
                  onChange(current) {
                    setPage(current)
                  }
                }}
                style={{ overflowX: 'auto' }}
                columns={columns}
                dataSource={dataWithDetails}
                onChange={handleChange}
              // rowKey={record => record.id}
              // bordered             
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CandidateList
