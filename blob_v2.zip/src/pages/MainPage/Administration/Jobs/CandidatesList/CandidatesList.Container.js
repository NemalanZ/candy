import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import { fetchAllCandidates, getAllCandidates, deleteCandidate, getCandidateStatus, fetchCandidatesStatus, isLoading } from '../../../../../redux/reducers/candidatesReducer'
import Component from './CandidatesList.Component'

const mapStateToProps = createStructuredSelector({
  allCandidates: getAllCandidates,
  candidateStatus: getCandidateStatus,
  loading: isLoading,
})

const mapDispatchToProps = {
  fetchAllCandidates,
  deleteCandidate,
  fetchCandidatesStatus
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
