import { DeleteOutlined, EditOutlined, FileExcelOutlined, } from '@ant-design/icons'
import { Popconfirm, Space, Table } from 'antd'
import { Excel } from 'antd-table-saveas-excel'
import { isEmpty, project } from 'ramda'
import React, { useEffect, useState } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, Outlet, useNavigate } from 'react-router-dom'
import { itemRender, onShowSizeChange } from '../../../Paginationfunction'
import { CSVLink } from 'react-csv'

const ManageJobs = ({ fetchAllJobs, allJobs, deleteJob, loading }) => {
  const navigate = useNavigate()
  const [page, setPage] = useState(1)
  const [filteredInfo, setFilteredInfo] = useState({});
  const [sortedInfo, setSortedInfo] = useState({});

  const excelJobs = project(['job_id', 'job_title', 'company_name', 'experience', 'vacancy_count', 'city_name', 'state_name', 'job_type_name', 'date_of_requisition', 'job_status'], allJobs)

  const handleChange = (pagination, filters, sorter) => {
    console.log('Various parameters', pagination, filters, sorter);
    setFilteredInfo(filters);
    setSortedInfo(sorter);
  };

  useEffect(() => {
    fetchAllJobs()
  }, [])

  const dataWithDetails = !isEmpty(allJobs)
    ? allJobs.map((details, index) => ({
      ...details,
      key: index,
      id: details.job_id,
      role: details.job_title,
      client: details.company_name,
      experience: `${details.experience}`,
      vacancy: details.vacancy_count,
      location: details.city_name,
      // location: `${details.city}, ${details.state}`, .split("").reverse().join("")
      dateOfReq: details.date_of_requisition.slice(0, 10),
      jobType: details.job_type_name,
      status: details.job_status
    }))
    : []

  const handleDeleteJob = (id) => {
    deleteJob(id)
  }

  const columns = [
    {
      title: 'Id',
      key: 'serial',
      // dataIndex: 'id',
      render: (item, text, serial) => (page - 1) * 10 + serial + 1
    },
    {
      title: 'Job Title',
      dataIndex: 'role',
      editTable: true,
      render: (_, record) => (
        <Link to='jobDetails' state={record.id}> {record.role}</Link>
      ),
      sorter: (a, b) => a.role.localeCompare(b.role)
    },
    {
      title: 'Client',
      dataIndex: 'client',
      filters: [
        {
          text: 'Google',
          value: 'Google'
        },
        {
          text: 'Microsoft',
          value: 'Microsoft'
        },
        {
          text: 'Qbotica',
          value: 'Qbotica'
        },
        {
          text: 'Qspiders',
          value: 'Qspiders'
        }
      ],
      onFilter: (value, record) => record.client === value,
      // sorter: (a, b) => a.client.localeCompare(b.client)
    },
    {
      title: 'location',
      dataIndex: 'location',
      sorter: (a, b) => a.location.localeCompare(b.location)
    },
    {
      title: 'Experience',
      dataIndex: 'experience',
      sorter: (a, b) => {
        const aNum = parseInt(a.experience);
        const bNum = parseInt(b.experience);
        if (isNaN(aNum) && isNaN(bNum)) {
          return a.experience.localeCompare(b.experience);
        }
        if (isNaN(aNum)) {
          return 1;
        }
        if (isNaN(bNum)) {
          return -1;
        }
        return aNum - bNum;
      },
    },
    {
      title: 'Vacancy',
      dataIndex: 'vacancy',
      sorter: (a, b) => a.vacancy - b.vacancy
    },
    {
      title: 'Job Type',
      dataIndex: 'jobType',
      filters: [
        {
          text: 'Full-Time',
          value: 'Full-Time'
        },
        {
          text: 'Part-Time',
          value: 'Part-Time'
        },
        {
          text: 'Intern',
          value: 'Intern'
        }
      ],
      onFilter: (value, record) => record.jobType === value,
      // filterMultiple: false,
      // sorter: (a, b) => a.jobType.localeCompare(b.jobType)
    },
    {
      title: 'Status',
      dataIndex: 'status',
      render(text, record) {
        return {
          props: {
            style: {
              color:
                record.status === 'Open'
                  ? 'green'
                  : record.status === 'On Hold'
                    ? '#f3b800'
                    : record.status === 'Closed'
                      ? 'red'
                      : 'white'
            }
          },
          children: <div>{text}</div>
        }
      },
      filters: [
        {
          text: 'Open',
          value: 'Open'
        },
        {
          text: 'Closed',
          value: 'Closed'
        },
        {
          text: 'On Hold',
          value: 'On Hold'
        }
      ],
      onFilter: (value, record) => record.status === value
      // filterMultiple: false
    },
    {
      title: 'Start Date',
      dataIndex: 'dateOfReq',
      sorter: (a, b) => new Date(a.dateOfReq) - new Date(b.dateOfReq)
    },
    {
      title: 'Action',
      dataIndex: 'action',
      render: (_, record) => (
        <Space>
          <Link to='editJob' state={record.id}>
            <EditOutlined style={{ fontSize: '1rem' }} />
          </Link>
          <Popconfirm
            title='Are you sure want to delete ?'
            onConfirm={() => {
              handleDeleteJob(record.id)
            }}
          >
            <DeleteOutlined style={{ color: 'red', fontSize: '1rem' }} />
          </Popconfirm>
        </Space>
      )
    }
  ]

  const handleClick = () => {
    const excel = new Excel()
    excel
      .addSheet('test')
      .addColumns(columns.slice(0, 8))
      .addDataSource(dataWithDetails)
      .saveAs('Excel.xlsx')
    // console.log(excel)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Requisition - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        {/* Page Header */}
        {/* {isLoading} */}
        <div className='page-header'>
          <div className='row align-items-center'>
            <div className='col'>
              <h3 className='page-title'>Jobs</h3>
              <ul className='breadcrumb'>
                <li className='breadcrumb-item'>
                  <Link to='/dashboard'>Dashboard</Link>
                </li>
                <li className='breadcrumb-item'>Jobs</li>
              </ul>
            </div>
            {/* <div className="top-nav-search">
              <a href="" className="responsive-search">
                <i className="fa fa-search" />
              </a>
              <form>
                <input className="form-control" type="text" placeholder="Search here" />
                <button className="btn" type="submit"><i className="fa fa-search" /></button>
              </form>
            </div> */}
            <div className='col-auto float-end ml-auto'>
              <button className='btn export-btn'>
                <CSVLink
                  data={excelJobs}
                  onClick={() => {
                    console.log("clicked")
                  }}
                  style={{
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <FileExcelOutlined style={{ paddingRight: '3px' }} />
                  Export
                </CSVLink>
              </button>
              {/* <button className='btn export-btn' onClick={handleClick}>
                <i className='fa-regular fa-file-excel' />
                Export
              </button> */}
            </div>
            <div className='col-auto float-end ml-auto'>
              <button
                className='btn add-btn'
                onClick={() => navigate('addJob')}
              >
                <i className='fa fa-plus' />
                Create
              </button>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        <div className='row'>
          <div className='col-md-12'>
            <div className='table-responsive'>
              <Table
                className='table-striped'
                pagination={{
                  // total: dataWithDetails.length,
                  // showTotal: (total, range) =>
                  //   `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                  showSizeChanger: true,
                  onShowSizeChange,
                  itemRender,
                  onChange(current) {
                    setPage(current)
                  }
                }}
                style={{ overflowX: 'auto' }}
                columns={columns}
                dataSource={dataWithDetails}
                onChange={handleChange}
              // rowKey={record => record.id}
              />
            </div>
          </div>
        </div>
      </div>
      <Outlet />
    </div>
  )
}

export default ManageJobs
