import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import { fetchDashboardData } from '../../../redux/reducers/dashboardReducer'
import { getUserName, logoutRedux } from '../../../redux/reducers/userReducer'
import DefaultLayout from './DefaultLayout'

const mapStateToProps = createStructuredSelector({
  userName: getUserName
})

const mapDispatchToProps = {
  fetchDashboardData,
  logoutRedux,
}

export default connect(mapStateToProps, mapDispatchToProps)(DefaultLayout)
