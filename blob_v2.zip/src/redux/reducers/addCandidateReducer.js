import { createSelector } from 'reselect'
import { prop, defaultTo, equals, map } from 'ramda'
import { POST_CANDIDATE_ACTION as ACTIONS } from '../actions'
import getJobDetailsApi from '../../api/getJobDetails'
import postCandidateApi from '../../api/postCandidate'
import getSkillsApi from '../../api/getSkills'
import getCitiesApi from '../../api/getCities'
import getStatesApi from '../../api/getStates'
import getCountriesApi from '../../api/getCountries'
import getCandidateRoundsApi from '../../api/getCandidateRounds'
import getCandidateStatusApi from '../../api/getCandidateStatus'

const initialState = {
  error: null,
  loading: false,
  jobId: '',
  jobTitle: '',
  firstName: '',
  lastName: '',
  gender: '',
  emailId: '',
  phone: '',
  experience: '',
  mainSkill: '',
  secondarySkill: '',
  address: '',
  city: '',
  pinCode: '',
  state: '',
  country: '',
  resume: '',
  rounds: '',
  status: '',

  skills: [],
  cities: [],
  states: [],
  countries: [],
  candidateRounds: [],
  candidateStatus: [],
  jobDetails: []
}

const getSlice = prop('addCandidate')

export const getError = createSelector(getSlice, prop('error'))
export const isLoading = createSelector(getSlice, prop('loading'))
export const getJobTitle = createSelector(getSlice, prop('jobTitle'))
export const getFirstName = createSelector(getSlice, prop('firstName'))
export const getLastName = createSelector(getSlice, prop('lastName'))
export const getGender = createSelector(getSlice, prop('gender'))
export const getEmailId = createSelector(getSlice, prop('emailId'))
export const getPhone = createSelector(getSlice, prop('phone'))
export const getExperience = createSelector(getSlice, prop('experience'))
export const getMainSkill = createSelector(getSlice, prop('mainSkill'))
export const getSecondarySkill = createSelector(
  getSlice,
  prop('secondarySkill')
)
export const getAddress = createSelector(getSlice, prop('address'))
export const getCity = createSelector(getSlice, prop('city'))
export const getPinCode = createSelector(getSlice, prop('pinCode'))
export const getStateValue = createSelector(getSlice, prop('state'))
export const getCountry = createSelector(getSlice, prop('country'))
export const getRounds = createSelector(getSlice, prop('rounds'))
export const getStatus = createSelector(getSlice, prop('status'))
export const getResume = createSelector(getSlice, prop('resume'))

// MASTER TABLE
export const getSkills = createSelector(getSlice, prop('skills'))
export const getCities = createSelector(getSlice, prop('cities'))
export const getStates = createSelector(getSlice, prop('states'))
export const getCountries = createSelector(getSlice, prop('countries'))
export const getCandidateRounds = createSelector(getSlice, prop('candidateRounds'))
export const getCandidateStatus = createSelector(getSlice, prop('candidateStatus'))
export const getJobDetails = createSelector(getSlice, prop('jobDetails'))
export const getJobId = createSelector(getSlice, prop('jobId'))

export const postCandidate = (navigate) => async (dispatch, getState) => {
  dispatch({
    type: ACTIONS.POST_CANDIDATE_REQUEST
  })
  try {
    const payload = {
      Applied_Jobs: getJobId(getState()),
      first_name: getFirstName(getState()),
      last_name: getLastName(getState()),
      gender: getGender(getState()),
      email: getEmailId(getState()),
      contact_no: getPhone(getState()),
      experience: getExperience(getState()),
      main_skill: getMainSkill(getState()),
      secondary_skill: getSecondarySkill(getState()),
      address: getAddress(getState()),
      city_id: getCity(getState()),
      pin_code: getPinCode(getState()),
      state_id: getStateValue(getState()),
      country_id: getCountry(getState()),
      // profile_status: getRounds(getState()),
      // selection_status: getStatus(getState()),
      resume: getResume(getState())
    }
    const postCandidateData = await postCandidateApi(payload)
    // console.log(postCandidateData);
    dispatch({
      type: ACTIONS.POST_CANDIDATE_SUCCESS,
      data: postCandidateData,
      payload
    })
    if (
      equals(
        'Candidate Details saved successfully ',
        prop('response_message', postCandidateData)
      )
    ) {
      navigate('/candidates')
      alert(postCandidateData.response_message)
    } else {
      dispatch({
        type: ACTIONS.POST_CANDIDATE_FAILURE,
        error: postCandidateData.response_message
      })
    }
  } catch (error) {
    if (error && error.response && error.response.data) {
      alert(error.response.data.Message)
      return dispatch({
        type: ACTIONS.POST_CANDIDATE_FAILURE,
        error: error.response.data.Message
      })
    }
    dispatch({
      type: ACTIONS.POST_CANDIDATE_FAILURE,
      error: error
    })
  }
}

export const fetchMasterData = (id) => async (dispatch) => {
  dispatch({
    type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_REQUEST
  })
  try {
    const skillsData = await getSkillsApi()
    const citiesData = await getCitiesApi()
    const statesData = await getStatesApi()
    const countriesData = await getCountriesApi()
    const candidateRoundsData = await getCandidateRoundsApi()
    const candidateStatusData = await getCandidateStatusApi()
    const jobDetailsData = await getJobDetailsApi(id)

    const data = {
      skillsData,
      citiesData,
      statesData,
      countriesData,
      candidateRoundsData,
      candidateStatusData,
      jobDetailsData
    }
    // console.log('masterData', data)
    dispatch({
      type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_SUCCESS,
      masterData: data
    })
  } catch (error) {
    dispatch({
      type: ACTIONS.CANDIDATE_MASTER_DATA_ACTION_FAILURE,
      error
    })
  }
}
export const setJobTitle = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_JOB_TITLE,
    value: defaultTo('', value)
  })
}
export const setFirstName = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_FIRSTNAME,
    value: defaultTo('', value)
  })
}
export const setLastName = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_LASTNAME,
    value: defaultTo('', value)
  })
}
export const setGender = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_GENDER,
    value: defaultTo('', value)
  })
}
export const setEmailId = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_EMAILID,
    value: defaultTo('', value)
  })
}
export const setPhone = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_PHONE,
    value: defaultTo('', value)
  })
}
export const setExperience = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_EXPERIENCE,
    value: defaultTo('', value)
  })
}
export const setMainSkill = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_MAIN_SKILL,
    value: defaultTo('', value)
  })
}
export const setSecondarySkill = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_SECONDARY_SKILL,
    value: defaultTo('', value)
  })
}
export const setAddress = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_ADDRESS,
    value: defaultTo('', value)
  })
}
export const setCity = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_CITY,
    value: defaultTo('', value)
  })
}
export const setPinCode = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_PINCODE,
    value: defaultTo('', value)
  })
}
export const setState = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_STATE,
    value: defaultTo('', value)
  })
}
export const setCountry = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_COUNTRY,
    value: defaultTo('', value)
  })
}
export const setRounds = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_ROUNDS,
    value: defaultTo('', value)
  })
}
export const setStatus = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_STATUS,
    value: defaultTo('', value)
  })
}
export const setResume = (value) => (dispatch) => {
  dispatch({
    type: ACTIONS.SET_RESUME,
    value: defaultTo('', value)
  })
}

export default (state = initialState, { type, ...action } = {}) => {
  switch (type) {
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_SUCCESS:
      return {
        ...state,
        masterData: action.masterData,
        skills: action.masterData.skillsData,
        cities: action.masterData.citiesData,
        states: action.masterData.statesData,
        countries: action.masterData.countriesData,
        candidateRounds: action.masterData.candidateRoundsData,
        candidateStatus: action.masterData.candidateStatusData,
        jobDetails: action.masterData.jobDetailsData,
        loading: false,
        error: false
      }
    case ACTIONS.CANDIDATE_MASTER_DATA_ACTION_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.POST_CANDIDATE_REQUEST: {
      return {
        ...state,
        loading: true
      }
    }
    case ACTIONS.POST_CANDIDATE_SUCCESS: {
      return {
        ...state,
        jobTitle: prop('jobTitle', action.data),
        firstName: prop('firstName', action.data),
        lastName: prop('lastName', action.data),
        gender: prop('gender', action.data),
        emailId: prop('emailId', action.data),
        phone: prop('phone', action.data),
        experience: prop('experience', action.data),
        mainSkill: prop('mainSkill', action.data),
        secondarySkill: prop('secondarySkill', action.data),
        address: prop('address', action.data),
        city: prop('city', action.data),
        pinCode: prop('pinCode', action.data),
        state: prop('state', action.data),
        country: prop('country', action.data),
        rounds: prop('rounds', action.data),
        status: prop('status', action.data),
        resume: prop('resume', action.data),
        loading: false,
        error: false
      }
    }
    case ACTIONS.POST_CANDIDATE_FAILURE: {
      return {
        ...state,
        error: action.error,
        loading: false
      }
    }
    case ACTIONS.SET_JOB_TITLE: {
      const jobList = map(e => ({ job_id: e }), action.value)
      return {
        ...state,
        jobId: jobList
      }
    }
    case ACTIONS.SET_FIRSTNAME: {
      return {
        ...state,
        firstName: action.value
      }
    }
    case ACTIONS.SET_LASTNAME: {
      return {
        ...state,
        lastName: action.value
      }
    }
    case ACTIONS.SET_GENDER: {
      return {
        ...state,
        gender: action.value
      }
    }
    case ACTIONS.SET_EMAILID: {
      return {
        ...state,
        emailId: action.value
      }
    }
    case ACTIONS.SET_PHONE: {
      return {
        ...state,
        phone: action.value
      }
    }
    case ACTIONS.SET_EXPERIENCE: {
      return {
        ...state,
        experience: action.value
      }
    }
    case ACTIONS.SET_MAIN_SKILL: {
      return {
        ...state,
        mainSkill: action.value
      }
    }
    case ACTIONS.SET_SECONDARY_SKILL: {
      return {
        ...state,
        secondarySkill: action.value
      }
    }
    case ACTIONS.SET_ADDRESS: {
      return {
        ...state,
        address: action.value
      }
    }
    case ACTIONS.SET_CITY: {
      return {
        ...state,
        city: action.value
      }
    }
    case ACTIONS.SET_PINCODE: {
      return {
        ...state,
        pinCode: action.value
      }
    }
    case ACTIONS.SET_STATE: {
      return {
        ...state,
        state: action.value
      }
    }
    case ACTIONS.SET_COUNTRY: {
      return {
        ...state,
        country: action.value
      }
    }
    case ACTIONS.SET_ROUNDS: {
      return {
        ...state,
        rounds: action.value
      }
    }
    case ACTIONS.SET_STATUS: {
      return {
        ...state,
        status: action.value
      }
    }
    case ACTIONS.SET_RESUME: {
      return {
        ...state,
        resume: action.value
      }
    }
    default:
      return initialState
  }
}
