## qBotica HRMS ReadMe

## Requirements

## Node: v16.16.0

## React: v.18.2.0

## npm: v8.11.0

## Instructions to Run

Package Installation

> yarn add (or) yarn

Dev Execution

> yarn run start (or) yarn start

Build execution

> yarn run build (or) yarn build
