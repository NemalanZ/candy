import { configureStore } from '@reduxjs/toolkit'
import { routerMiddleware } from 'connected-react-router'
import { createBrowserHistory } from 'history'
import thunk from 'redux-thunk'
import rootReducer from './reducers'

export const history = createBrowserHistory()

// import logger from "redux-logger";

const combineReducers = rootReducer(history)

const middlewares = [routerMiddleware(history), thunk]

const store = configureStore({
  reducer: combineReducers,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(middlewares),
  devTools: process.env.NODE_ENV !== 'production'
})

if (process.env.NODE_ENV !== 'production' && module.hot) {
  module.hot.accept('./reducers/index', () => store.replaceReducer(combineReducers))
}

export default store
