import axios from './getAxios'

export default async (payload) => {
  const { data } = await axios({
    method: 'POST',
    url: 'jobPost/saveJobPosts',
    data: payload
  })
  return data
}
