import axios from './getAxios'

export default async (id) => {
  const { data } = await axios({
    method: 'DELETE',
    url: `jobPost/deleteSpecificJobPosting?job_id=${id}`
  })
  return data
}
