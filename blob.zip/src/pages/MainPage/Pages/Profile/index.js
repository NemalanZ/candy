/**
 * Tables Routes
 */
import React from 'react'
import { Route, Routes } from 'react-router-dom'

import ClientProfile from './clientprofile'
import EmployeeProfile from './employeeprofile'

const subscriptionroute = ({ match }) => (
  <Routes>
    {/* <Redirect exact from={`${match.url}/`} to={`${match.url}/employee-profile`} /> */}
    <Route path={`${match.url}/employee-profile`} component={EmployeeProfile} />
    <Route path={`${match.url}/client-profile`} component={ClientProfile} />
  </Routes>
)

export default subscriptionroute
