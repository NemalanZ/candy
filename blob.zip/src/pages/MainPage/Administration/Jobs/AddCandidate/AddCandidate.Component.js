import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate, useParams } from 'react-router-dom'
import {
  Select, DatePicker, Input, Upload, Button, Space, Form, Row, Col
} from 'antd'
import { map } from 'ramda'
import { UploadOutlined } from '@ant-design/icons'

const AddCandidate = ({
  postCandidate,
  fetchMasterData,
  jobId,
  jobTitle,
  firstName,
  lastName,
  gender,
  emailId,
  phone,
  experience,
  mainSkill,
  secondarySkill,
  address,
  city,
  pinCode,
  state,
  country,
  rounds,
  status,
  resume,
  skills,
  cities,
  states,
  countries,
  jobDetails,
  setJobTitle,
  setFirstName,
  setLastName,
  setGender,
  setEmailId,
  setPhone,
  setExperience,
  setMainSkill,
  setSecondarySkill,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setResume,
  candidateRounds,
  candidateStatus,
  setRounds,
  setStatus
}) => {
  const navigate = useNavigate()
  const { id } = useParams()
  const [form] = Form.useForm();
  const options = map(item => ({ value: item.job_id, label: item.job_title }), jobDetails)

  useEffect(() => {
    fetchMasterData(id)
  }, [])

  const handleSubmit = () => {
    postCandidate(navigate)
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Create Candidate - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Add Candidate</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'>
                      <Link to='/candidates'>Candidates</Link>
                    </li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <Form
              form={form}
              name="formJob"
              layout={'vertical'}
              style={{ maxWidth: '100%' }}
              colon={false}
              initialValues={{
                remember: true
              }}
              onFinish={handleSubmit}
            >
              <Row gutter={16}>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12}>
                  <Form.Item
                    label='Job Title'
                    name='JobTitle'
                    rules={[
                      {
                        required: true,
                        message: 'Job Title required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      mode='multiple'
                      allowClear
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={jobId}
                      onChange={value => setJobTitle(value)}
                      options={options}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12} >
                  <Form.Item
                    label='Gender'
                    name="gender"
                    rules={[
                      {
                        required: true,
                        message: 'Gender required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={gender}
                      onChange={(value) => setGender(value)}
                      options={[
                        { value: 'Male', label: 'Male' },
                        { value: 'Female', label: 'Female' }
                      ]}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    label='First Name'
                    name='firstName'
                    rules={[
                      {
                        required: true,
                        message: 'First Name required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    label='Last Name'
                    name='lastName'
                    rules={[
                      {
                        required: true,
                        message: 'Last Name required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Contact</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    label='Email'
                    name='email'
                    rules={[
                      {
                        required: true,
                        message: 'Email required',
                      },
                      {
                        pattern: "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",
                        message: "Invalid Email (examplemail@gmail.com)",
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='email'
                      value={emailId}
                      onChange={(e) => setEmailId(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={12}>
                  <Form.Item
                    label='Phone'
                    name='phone'
                    rules={[
                      {
                        required: true,
                        message: 'Phone required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='number'
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Address</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <Form.Item
                    label='Address'
                    name="address"
                    rules={[
                      {
                        required: true,
                        message: 'Address required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Pin Code'
                    name='pinCode'
                    rules={[
                      {
                        required: true,
                        message: 'Pin Code required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='number'
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='City'
                    name='city'
                    rules={[
                      {
                        required: true,
                        message: 'City required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={city}
                      onChange={(value) => {
                        setCity(value)
                      }}
                      options={map(item => ({ value: item.city_id, label: item.city_name }), cities)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='State'
                    name='state'
                    rules={[
                      {
                        required: true,
                        message: 'State required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={state}
                      onChange={(value) => setState(value)}
                      options={map(item => ({ value: item.state_id, label: item.state_name }), states)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Country'
                    name='country'
                    rules={[
                      {
                        required: true,
                        message: 'Country required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={country}
                      onChange={(value) => setCountry(value)}
                      options={map(item => ({ value: item.country_id, label: item.country_name }), countries)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Experience & Skills</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Year of Experience'
                    name='experience'
                    rules={[
                      {
                        required: true,
                        message: 'Year of Experience required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={experience}
                      onChange={(e) => setExperience(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Main Skill'
                    name='mainSkill'
                    rules={[
                      {
                        required: true,
                        message: 'Main Skill required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={mainSkill}
                      onChange={(value) => setMainSkill(value)}
                      options={map(item => ({ value: item.skill_id, label: item.skill_name }), skills)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Secondary Skill'
                    name='secondarySkill'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={secondarySkill}
                      onChange={(e) => setSecondarySkill(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Resume</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <Form.Item
                    label='Upload File'
                    name='resume'
                  // rules={[
                  //   {
                  //     required: true,
                  //     message: 'Upload File required',
                  //   },
                  // ]}
                  >
                    <Upload
                      listType="picture"
                    // value={resume}
                    // onChange={(value) => setResume(value)}
                    >
                      <Button icon={<UploadOutlined />}>Click to upload</Button>
                    </Upload>
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <div className='submit-section'>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      htmlType="submit"
                      className='btn btn-primary submit-btn'
                    // onClick={handleSubmit}
                    >Save
                    </Button>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      className='btn btn-dark submit-btn'
                      type="button"
                      onClick={() => navigate('/candidates')}
                    >Cancel
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default AddCandidate
