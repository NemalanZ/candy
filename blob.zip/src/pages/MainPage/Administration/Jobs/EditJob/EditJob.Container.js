import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import {
  fetchMasterData, fetchPrevJobDetails, getAddress, getArchived, getCity, getClient,
  getClientAddress, getClients, getCountry, getDateOfRequisition, getExperience, getJobDescriptionFilePath,
  getJobDescriptionText, getJobId, getJobTitle,
  getJobType, getJobTypes, getJobStatus, getMaxSalary, getMinSalary, getPinCode, getRequisitionId, getSelectedClient, getStateValue, getVacancyCount, putJob, setAddress, setArchived, setCity, setClient, setCountry, setDateOfRequisition, setExperience, setJobDescriptionFilePath,
  setJobDescriptiontext, setJobTitle,
  setJobType, setJobStatus, setMaxSalary, setMinSalary, setPinCode,getJobDetails,
  // getCities,
  // getStates,
  // getCountries,
  setRequisitionId, setState, setVacancyCount
} from '../../../../../redux/reducers/editJobReducer'
import Component from './EditJob.Component'

const mapStateToProps = createStructuredSelector({
  jobId: getJobId,
  requisitionId: getRequisitionId,
  dateOfRequisition: getDateOfRequisition,
  jobTitle: getJobTitle,
  jobType: getJobType,
  jobStatus: getJobStatus,
  client: getClient,
  address: getAddress,
  city: getCity,
  pinCode: getPinCode,
  state: getStateValue,
  country: getCountry,
  experience: getExperience,
  vacancyCount: getVacancyCount,
  minSalary: getMinSalary,
  maxSalary: getMaxSalary,
  jobDescriptionFilePath: getJobDescriptionFilePath,
  jobDescriptionText: getJobDescriptionText,
  archived: getArchived,
  jobDetails:getJobDetails,

  jobTypes: getJobTypes,
  clients: getClients,
  clientAddress: getClientAddress,
  selectedClient: getSelectedClient
  // cities: getCities,
  // states: getStates,
  // countries: getCountries,
})

const mapDispatchToProps = {
  fetchPrevJobDetails,
  setRequisitionId,
  setDateOfRequisition,
  setJobTitle,
  setJobType,
  setJobStatus,
  setClient,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setExperience,
  setVacancyCount,
  setMinSalary,
  setMaxSalary,
  setJobDescriptionFilePath,
  setJobDescriptiontext,
  setArchived,
  fetchMasterData,
  putJob
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
