import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import renderHTML from 'react-render-html'
import { Link, useParams } from 'react-router-dom'

const Jobdetails = ({
  fetchJobDetails,
  jobDetails,
  jobId,
  requisitionId,
  dateOfRequisition,
  jobTitle,
  jobType,
  client,
  address,
  city,
  pinCode,
  state,
  country,
  experience,
  vacancyCount,
  minSalary,
  maxSalary,
  jobDescriptionFilePath,
  jobDescriptionText,
  archived
}) => {
  const { id } = useParams()

  useEffect(() => {
    fetchJobDetails(id)
  }, [])

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Jobs - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>

      {/* Page Content */}
      <div className='content container-fluid'>
        {/* Page Header */}
        <div className='page-header'>
          <div className='row'>
            <div className='col-sm-12'>
              <h3 className='page-title'>Job Details</h3>
              <ul className='breadcrumb'>
                <li className='breadcrumb-item'><Link to='/jobs'>Jobs</Link></li>
                <li className='breadcrumb-item active'>Job Details</li>
              </ul>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        <div className='row'>
          <div className='col-md-8'>
            <div className='job-info job-widget'>
              <h3 className='job-title'>{jobTitle}</h3>
              <span className='job-client'>{client}</span>
              <ul className='job-post-det'>
                <li>
                  <i className='fa fa-calendar' /> Post Date:{' '}
                  <span className='text-blue'>{dateOfRequisition.slice(0, 10)}</span>
                </li>
                {/* <li>
                  <i className="fa fa-calendar" /> Last Date:{" "}
                  <span className="text-blue">{data.values.closingDate}</span>
                </li> */}
                {/* <li><i className="fa fa-user-o" /> Applications: <span className="text-blue">4</span></li> */}
                {/* <li><i className="fa fa-eye" /> Views: <span className="text-blue">3806</span></li> */}
              </ul>
            </div>
            <div className='job-content job-widget'>
              <div className='job-desc-title'>
                <h4>Job Description</h4>
              </div>
              <div className='job-description'>
                <p>
                  {renderHTML(jobDescriptionText)}
                </p>
              </div>
              {/* <div className="job-desc-title">
                <h4>Roles and Responsibilities</h4>
              </div>
              <div className="job-description">
                <p>
                  {data.values.resp}
                </p>
                <ul className="square-list">
                  <h4>Desired Skills</h4>
                  <li>
                    {data.values.skills}
                  </li>
                </ul>
              </div> */}
            </div>
          </div>
          <div className='col-md-4'>
            <div className='job-det-info job-widget'>
              {/* <button
                className="btn job-btn"
              ><Link to={`/app/administrator/update-requisition/${id}`}>
                Edit</Link>
              </button> */}
              <div className='info-list'>
                <span>
                  <i className='fa fa-bar-chart' />
                </span>
                <h5>Job Type</h5>
                <p>{jobType}</p>
              </div>
              <div className='info-list'>
                <span>
                  <i className='fa fa-money' />
                </span>
                <h5>Salary</h5>
                <p>{minSalary} - {maxSalary}</p>
              </div>
              <div className='info-list'>
                <span><i className='fa fa-suitcase' /></span>
                <h5>Experience</h5>
                <p>{experience}</p>
              </div>
              <div className='info-list'>
                <span><i className='fa fa-ticket' /></span>
                <h5>Vacancy</h5>
                <p>{vacancyCount}</p>
              </div>
              <div className='info-list'>
                <span>
                  <i className='fa fa-map-signs' />
                </span>
                <h5>Location</h5>
                <p>
                  {' '}
                  {client}
                  <br /> {address},
                  <br />{city}-{pinCode},
                  <br /> {state}
                  <br />{country}
                </p>
              </div>
              {/* <div className="info-list">
                <p className="text-truncate">
                  {" "}
                  818-978-7102
                  <br />{" "}
                  <a
                    href="mailto:danielporter@example.com"
                    title="danielporter@example.com"
                  >
                    danielporter@example.com
                  </a>
                  <br />{" "}
                  <a
                    href="https://www.example.com"
                    target="_blank"
                    title="https://www.example.com"
                  >
                    https://www.example.com
                  </a>
                </p>
              </div> */}
              {/* <div className="info-list text-center">
                 <a className="app-ends" href="#">Application ends in 2d 7h 6m</a>
               </div> */}
            </div>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default Jobdetails
