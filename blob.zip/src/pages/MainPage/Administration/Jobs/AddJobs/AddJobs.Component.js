import JoditEditor from 'jodit-react'
import { head, length, map, prop } from 'ramda'
import React, { useState, useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useNavigate } from 'react-router-dom'
import {
  Select, DatePicker, Input, Upload, Button, Space, Form, Row, Col
} from 'antd'
import { UploadOutlined } from '@ant-design/icons'
import { Editor } from '@tinymce/tinymce-react';
import ReactQuill from 'react-quill'
import "react-quill/dist/quill.snow.css";

const AddJob = ({
  postJob,
  requisitionId,
  dateOfRequisition,
  jobTitle,
  jobType,
  jobStatus,
  client,
  address,
  city,
  pinCode,
  state,
  country,
  experience,
  vacancyCount,
  minSalary,
  maxSalary,
  jobDescriptionFilePath,
  jobDescriptionText,
  archived,
  setRequisitionId,
  setDateOfRequisition,
  setJobTitle,
  setJobType,
  setJobStatus,
  setClient,
  setAddress,
  setCity,
  setPinCode,
  setState,
  setCountry,
  setExperience,
  setVacancyCount,
  setMinSalary,
  setMaxSalary,
  setJobDescriptionFilePath,
  setJobDescriptiontext,
  setArchived,
  fetchMasterData,
  jobTypes,
  clients,
  cities,
  states,
  countries,
  clientAddress,
  // companies,
  selectedClient
}) => {
  const navigate = useNavigate()
  const [form] = Form.useForm();
  const dateFormat = 'DD/MM/YYYY';

  useEffect(() => {
    fetchMasterData()
  }, [])

  useEffect(() => {
    if (length(selectedClient) === 1) {
      const selectedItem = head(selectedClient)
      setAddress(prop('address', selectedItem))
      setPinCode(prop('pin_code', selectedItem))
      setCity(prop('city_id', selectedItem))
      setState(prop('state_id', selectedItem))
      setCountry(prop('country_id', selectedItem))
    }
  }, [selectedClient])

  console.log('address:', selectedClient)

  const handleSubmit = () => {
    postJob(navigate)
  }

  const config = {
    height: 300,
  }

  return (
    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Add job - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-12'>
                  <h3 className='page-title'>Create Job</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'><Link to='/jobs'>Jobs</Link></li>
                    <li className='breadcrumb-item'>Create Job</li>
                  </ul>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <Form
              form={form}
              name="formJob"
              layout={'vertical'}
              style={{ maxWidth: '100%' }}
              colon={false}
              initialValues={{
                remember: true
              }}
              onFinish={handleSubmit}
            >
              <Row gutter={16}>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12}>
                  <Form.Item
                    label='Requisition Id'

                    rules={[
                      {
                        required: true,
                        message: 'Requisition Id required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='requisitionId'
                      type='text'
                      value={requisitionId}
                      onChange={e => setRequisitionId(e.target.value)}
                      disabled
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xs={24} sm={24} md={24} lg={12} >
                  <Form.Item
                    label='Date of Requisition'
                    name="Date of Requisition"
                    rules={[
                      {
                        required: true,
                        message: 'Date of Requisition required',
                      },
                    ]}
                  >
                    <DatePicker
                      size='large'
                      style={{
                        width: '100%'
                      }}

                      value={dateOfRequisition}
                      onChange={value => setDateOfRequisition(value)}
                      placement="bottomRight"
                      format={dateFormat}
                    // status={dateOfRequisition || "error"}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Job Details</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Job Title'
                    name='jobTitle'
                    rules={[
                      {
                        required: true,
                        message: 'Job Title required',
                      },
                    ]}
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      type='text'
                      value={jobTitle}
                      onChange={e => setJobTitle(e.target.value)}
                    // status={jobTitle || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Job Type'
                    name='jobType'
                    rules={[
                      {
                        required: true,
                        message: 'Job Type required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={jobType}
                      onChange={value => setJobType(value)}
                      options={map(item => ({ value: item.job_type_id, label: item.job_type_name }), jobTypes)}
                    // status={jobType || "error"}
                    >
                    </Select>
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Job Status'
                    name="jobStatus"
                    rules={[
                      {
                        required: true,
                        message: 'Job Status required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={jobStatus}
                      onChange={value => setJobStatus(value)}
                      options={[
                        { value: 'Open', label: 'Open' },
                        { value: 'On Hold', label: 'On Hold' },
                        { value: 'Closed', label: 'Closed' },
                      ]}
                    // status={jobStatus || "error"}
                    >
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Client Details</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Client'
                    name="client"
                    rules={[
                      {
                        required: true,
                        message: 'Client required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      placeholder='Select'
                      // value={client}
                      // status={client || "error"}
                      onChange={value => {
                        setClient(value)
                      }}
                    >
                      <option
                        defaultValue='Select'
                        hidden
                      >
                        {' '}
                        Select{' '}
                      </option>
                      {
                        clients.map((get, index) => (
                          <option key={index.toString()} value={get.client_id}> {get.company_name}</option>
                        ))
                      }
                    </Select>
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Location'
                    rules={[
                      {
                        required: true,
                        message: 'Location required',
                      },
                    ]}
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='location'
                      // value={address || 'Select'}
                      placeholder='Select'
                      options={map(item => ({ value: item.address, label: item.address }), selectedClient)}
                      onChange={value => {
                        setAddress(value)
                      }}
                    // status={address || "error"}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Postal Code'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='pinCode'
                      type='number'
                      value={pinCode}
                      onChange={e => setPinCode(e.target.value)}
                      disabled
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='City'
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='city'
                      placeholder='Select'
                      // value={city || 'Select'}
                      onChange={value => setCity(value)}
                      options={map(item => ({ value: item.city_id, label: item.city_name }), clientAddress)}
                      disabled
                    >
                    </Select>
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='State'
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='state'
                      placeholder='Select'
                      // value={state || 'Select'}
                      onChange={value => setState(value)}
                      options={map(item => ({ value: item.state_id, label: item.state_name }), clientAddress)}
                      disabled
                    >
                    </Select>
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={8}>
                  <Form.Item
                    label='Country'
                  >
                    <Select
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='country'
                      placeholder='Select'
                      // value={country || 'Select'}
                      onChange={value => setCountry(value)}
                      options={map(item => ({ value: item.country_id, label: item.country_name }), clientAddress)}
                      disabled
                    >
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Candidate Expertise</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Year of Experience'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='experience'
                      type='text'
                      value={experience}

                      onChange={e => setExperience(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Vacancy'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='vacancyCount'
                      type='number'
                      value={vacancyCount}
                      onChange={e => setVacancyCount(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Minimum Rate'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='minSalary'
                      type='number'
                      value={minSalary}
                      onChange={e => setMinSalary(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" span={6}>
                  <Form.Item
                    label='Maximum Rate'
                  >
                    <Input
                      size='large'
                      style={{
                        width: '100%'
                      }}
                      name='maxSalary'
                      type='number'
                      value={maxSalary}
                      onChange={e => setMaxSalary(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                <h4 style={{ color: '#ff8010' }}>Job Description</h4>
              </div>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <Form.Item
                    label='Upload File'
                  // rules={[
                  //   {
                  //     required: true,
                  //     message: 'Requisition Id required',
                  //   },
                  // ]}
                  >
                    <Upload
                      listType="picture"
                      value={jobDescriptionFilePath}
                    // onChange={value => setJobDescriptionFilePath(value)}
                    >
                      <Button icon={<UploadOutlined />}>Click to upload</Button>
                    </Upload>
                  </Form.Item>
                </Col>
              </Row>
              <p style={{ textAlign: 'center' }}>(or)</p>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <JoditEditor
                    value={jobDescriptionText}
                    onChange={jobDescriptionText => setJobDescriptiontext(jobDescriptionText)}
                    config={config}
                  />
                </Col>
              </Row>
              <Row gutter={16}>
                <Col className="gutter-row" span={24}>
                  <div className='submit-section'>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      htmlType="submit"
                      className='btn btn-primary submit-btn'
                    // onClick={handleSubmit}
                    >Save
                    </Button>
                    <Button
                      style={{
                        minWidth: '140px',
                        borderRadius: '50px',
                        margin: '0 10px',
                        padding: '10px 20px',
                        fontSize: '.8rem',
                        fontWeight: '600',
                        height: '40px',
                        color: 'white'
                      }}
                      className='btn btn-dark submit-btn'
                      type="button"
                      onClick={() => navigate('/jobs')}
                    >Cancel
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default AddJob
