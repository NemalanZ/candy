import JoditEditor from 'jodit-react'
import React, { useEffect } from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Link, useLocation } from 'react-router-dom'

const JobFormDetail = ({
  fetchJobDetails,
  jobDetails,
  jobId,
  requisitionId,
  dateOfRequisition,
  jobTitle,
  jobType,
  jobStatus,
  client,
  address,
  city,
  pinCode,
  state,
  country,
  experience,
  vacancyCount,
  minSalary,
  maxSalary,
  jobDescriptionFilePath,
  jobDescriptionText,
  archived
}) => {
  const location = useLocation()

  useEffect(() => {
    fetchJobDetails(location.state)
  }, [location.state])

  const config = {
    height: 300,
    readonly: true,
  }

  return (

    <div className='page-wrapper'>
      <HelmetProvider>
        <Helmet>
          <title>Job JobDetails - qBotica</title>
          <meta name='description' content='Login page' />
        </Helmet>
      </HelmetProvider>
      {/* Page Content */}
      <div className='content container-fluid'>
        <div className='row'>
          <div className='col-md-8 offset-md-2'>
            {/* Page Header */}
            <div className='page-header'>
              <div className='row'>
                <div className='col-sm-6'>
                  <h3 className='page-title'>Job JobDetails</h3>
                  <ul className='breadcrumb'>
                    <li className='breadcrumb-item'><Link to='/jobs'>Jobs</Link></li>
                    <li className='breadcrumb-item'>Job JobDetails </li>
                  </ul>
                </div>
                <div className='col-sm-6'>
                  <div className='submit-section-detail'>
                    <button
                      type='button'
                      className='btn btn-dark submit-btn'
                    >
                      <Link to='/jobs/editJob' state={location.state} style={{ color: "white" }}>
                        Edit
                      </Link>
                    </button>
                    {/* <button
                      type='button'
                      className='btn btn-primary submit-btn'
                      onClick={() => navigate(`/jobs/jobDetails/${id}/addCandidate`)}
                    >Add Candidate
                    </button> */}
                  </div>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <div className='row' />
            <fieldset disabled>
              <form>
                <div className='row'>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>
                        Requisition ID
                      </label>
                      <input
                        type='text'
                        name='requisitionId'
                        className='form-control'
                        value={requisitionId}
                      />
                    </div>
                  </div>
                  <div className='col-sm-6'>
                    <div className='form-group'>
                      <label>Date of Requisition</label>
                      <input
                        type='date'
                        name='dateOfRequisition'
                        className='form-control'
                        value={dateOfRequisition}
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Job Details</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>
                        Job Title
                      </label>
                      <input
                        type='text'
                        name='jobTitle'
                        className='form-control'
                        value={jobTitle}
                        onChange={e => setJobTitle(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>
                        Job Type
                      </label>
                      <input
                        type='text'
                        name='jobType'
                        className='form-control'
                        value={jobType}
                        onChange={e => setJobTitle(e.target.value)}
                      />

                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Job Status</label>
                      <input
                        type='text'
                        name='jobStatus'
                        className='form-control'
                        value={jobStatus}
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Client Details</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>
                        Client
                      </label>
                      <input
                        type='text'
                        name='client'
                        className='form-control'
                        value={client}
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>
                        Location
                      </label>
                      <input
                        type='text'
                        name='address'
                        className='form-control'
                        value={address}
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Postal Code</label>
                      <input
                        type='text'
                        name='pinCode'
                        className='form-control'
                        value={pinCode}
                      />
                    </div>
                  </div>

                </div>
                <div className='row'>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>City</label>
                      <input
                        type='text'
                        name='city'
                        className='form-control'
                        value={city}
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>State</label>
                      <input
                        type='text'
                        name='state'
                        className='form-control'
                        value={state}
                      />
                    </div>
                  </div>
                  <div className='col-sm-4'>
                    <div className='form-group'>
                      <label>Country</label>
                      <input
                        type='text'
                        name='country'
                        className='form-control'
                        value={country}
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Candidate Expertise</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Year of Experience</label>
                      <input
                        type='text'
                        name='experience'
                        className='form-control'
                        value={experience}
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Vacancy</label>
                      <input
                        type='text'
                        name='vacancyCount'
                        className='form-control'
                        value={vacancyCount}
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Minimum Rate</label>
                      <input
                        type='number'
                        name='minSalary'
                        className='form-control'
                        value={minSalary}
                      />
                    </div>
                  </div>
                  <div className='col-sm-3'>
                    <div className='form-group'>
                      <label>Maximum Rate</label>
                      <input
                        type='number'
                        name='maxSalary'
                        className='form-control'
                        value={maxSalary}
                      />
                    </div>
                  </div>
                </div>
                <div style={{ borderBottom: '1px solid #ced4da', margin: '10px 0' }}>
                  <h4 style={{ color: '#ff8010' }}>Job Description</h4>
                </div>
                <div className='row'>
                  <div className='col-sm-12'>
                    <div className='form-group'>
                      <label>Upload File</label>
                      <input
                        type='file'
                        name='jobDescriptionFilePath'
                        className='form-control'
                        // value={jobDescriptionFilePath}
                        accept='.pdf'
                      />
                    </div>
                  </div>
                </div>
                <div className='row'>
                  <div className='col-sm-12'>
                    <div className='form-group'>
                      <p style={{ textAlign: 'center' }}>(or)</p>
                      <JoditEditor
                        name='jobDescriptionFilePath'
                        value={jobDescriptionText}
                        config={config}
                      />
                    </div>
                  </div>
                </div>
              </form>
            </fieldset>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  )
}

export default JobFormDetail
