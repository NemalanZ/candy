import { connect } from 'react-redux'
import { createStructuredSelector } from 'reselect'
import {
  fetchJobDetails,
  getJobDetails,
  getJobId,
  getRequisitionId,
  getDateOfRequisition,
  getJobTitle,
  getJobType,
  getJobStatus,
  getClient,
  getAddress,
  getCity,
  getPinCode,
  getStateValue,
  getCountry,
  getExperience,
  getVacancyCount,
  getMinSalary,
  getMaxSalary,
  getJobDescriptionFilePath,
  getJobDescriptionText,
  getArchived
} from '../../../../../redux/reducers/jobDetailsReducer'
import Component from './JobFormDetail.Component'

const mapStateToProps = createStructuredSelector({
  jobDetails: getJobDetails,
  jobId: getJobId,
  requisitionId: getRequisitionId,
  dateOfRequisition: getDateOfRequisition,
  jobTitle: getJobTitle,
  jobType: getJobType,
  jobStatus: getJobStatus,
  client: getClient,
  address: getAddress,
  city: getCity,
  pinCode: getPinCode,
  state: getStateValue,
  country: getCountry,
  experience: getExperience,
  vacancyCount: getVacancyCount,
  minSalary: getMinSalary,
  maxSalary: getMaxSalary,
  jobDescriptionFilePath: getJobDescriptionFilePath,
  jobDescriptionText: getJobDescriptionText,
  archived: getArchived
})

const mapDispatchToProps = {
  fetchJobDetails
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)
