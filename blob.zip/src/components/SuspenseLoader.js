import React, { Suspense } from 'react'
import Spinner from './Spinner'

const SuspenseLoader = (Component) => (props) => (
  <Suspense fallback={<Spinner />}>
    <Component {...props} />
  </Suspense>
)

export default SuspenseLoader
